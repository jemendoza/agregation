package polytech.tours.di.parallel.td2.exo3_2;

import java.util.ArrayList;
import java.util.List;

/**
 * Our own version of a reentrant lock providing fairness
 * @author Jorge E. Mendoza (dev@jorge-mendoza.com)
 * @version %I%, %G%
 *
 */
public class FairLock {
	/**
	 * True if the lock is locked and false otherwise
	 */
	private boolean isLocked = false;
	/**
	 * A reference to the thread holding the lock
	 */
	private Thread lockingThread  = null;
	/**
	 * A list of objects on which waiting threads wait
	 */
	private List<QueueObject> queue = new ArrayList<QueueObject>();
	/**
	 * Locks the lock
	 * @throws InterruptedException
	 */
	public void lock() throws InterruptedException{
		//Creates an queue object representing the calling thread's position in the queue
		QueueObject queueObject = new QueueObject();
		//Assume the lock is locked for the calling thread
		boolean lockedByAnotherThread = true;
		synchronized(this){
			//Get in the queue
			queue.add(queueObject);
		}
		//While the lock is locked by another thread
		while(lockedByAnotherThread){
			synchronized(this){
				/*if the lock is still locked or the calling thread is
				 *not the fist in the queue
				 */
				lockedByAnotherThread=isLocked||queue.get(0)!=queueObject;
				if(!lockedByAnotherThread){
					isLocked = true;
					queue.remove(queueObject);
					lockingThread = Thread.currentThread();
					return; //The calling thread obtained the lock
				}
			}
			//If the calling thread cannot acquire the lock then wait
			try{
				queueObject.doWait();
			}catch(InterruptedException e){
				synchronized(this) { 
					queue.remove(queueObject); 
				}
				throw e;
			}
		}
	}
	/**
	 * Unlocks the lock
	 */
	public synchronized void unlock(){
		if(this.lockingThread != Thread.currentThread()){
			throw new IllegalMonitorStateException("Calling thread has not locked this lock");
		}
		isLocked = false;
		lockingThread = null;
		if(queue.size() > 0){
			queue.get(0).doNotify();
		}
	}
}