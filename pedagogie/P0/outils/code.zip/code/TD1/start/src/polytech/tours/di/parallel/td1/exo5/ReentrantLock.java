package polytech.tours.di.parallel.td1.exo5;

/**
 * Implements a simple re-entrant lock
 * @author Jorge E. Mendoza (dev@jorge-mendoza.com)
 * @version %I%, %G%
 *
 */
public class ReentrantLock {
	
	//TODO TD1-EXO5: implement this class
	
	/**
	 * Acquires the lock.
	 */
	public void lock() throws InterruptedException{
		//TODO TD1-EXO3: implement this method, revise method declaration if needed
	}
	
	/**
	 * Releases the lock
	 */
	public void unlock(){
		//TODO TD1-EXO3: implement this method, revise method declaration if needed
	}
	
}
