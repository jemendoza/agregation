package polytech.tours.di.parallel.td1.exo3;

/**
 * Implements a lock
 * @author Jorge E. Mendoza (dev@jorge-mendoza.com)
 * 
 */
public class Lock {
	
	//TODO TD1-EXO3: implement this class
	
	/**
	 * Acquires the lock.
	 */
	public void lock() throws InterruptedException {
		//TODO TD1-EXO3: implement this method, revise method declaration if needed
	}
	/**
	 * Releases the lock
	 */
	public void unlock(){
		//TODO TD1-EXO3: implement this method, revise method declaration if needed
	}
	
}
