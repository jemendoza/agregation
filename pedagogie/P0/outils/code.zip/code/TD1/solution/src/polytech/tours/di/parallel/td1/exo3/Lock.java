package polytech.tours.di.parallel.td1.exo3;

/**
 * Implements a lock
 * @author Jorge E. Mendoza (dev@jorge-mendoza.com)
 * 
 */
public class Lock {
	/**
	 * True if the lock is locked and false otherwise
	 */
	private boolean isLocked = false;
	/**
	 * Acquires the lock.
	 * 
	 * @throws InterruptedException
	 */
	public synchronized void lock() throws InterruptedException{
		while(isLocked){
			System.out.println(Thread.currentThread().getName() +
					" waiting for the lock @ "+ System.nanoTime());
			wait();
		}
		isLocked = true;
		System.out.println(Thread.currentThread().getName() +
				" obtained the lock @ "+ System.nanoTime());
	}
	/**
	 * Releases the lock
	 */
	public synchronized void unlock(){
		System.out.println(Thread.currentThread().getName() +
				" released the lock @ "+ System.nanoTime());
		isLocked = false;
		notify();
	}
}
