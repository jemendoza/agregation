package polytech.tours.di.parallel.td1.exo5;

/**
 * Implements a simple re-entrant lock
 * @author Jorge E. Mendoza (dev@jorge-mendoza.com)
 * @version %I%, %G%
 *
 */
public class ReentrantLock {
	/**
	 * True if the lock is locked and false otherwise
	 */
	private boolean isLocked = false;
	/**
	 * A reference to the thread holding the lock
	 */
	private Thread lockedBy;
	/**
	 * The number of times the thread has acquired the lock
	 */
	int lockedCount = 0;

	/**
	 * Acquires the lock.
	 * 
	 * @throws InterruptedException
	 */
	public synchronized void lock() throws InterruptedException{
		//get a reference to the calling thread
		Thread callingThread = Thread.currentThread();
		while(isLocked && callingThread!=lockedBy){
			System.out.println(Thread.currentThread().getName() +
					" waiting for the lock @ "+ System.nanoTime());
			wait();
		}
		isLocked = true;
		lockedBy=callingThread;
		lockedCount++;
		System.out.println(Thread.currentThread().getName() +
				" obtained the lock @ "+ System.nanoTime());
	}
	/**
	 * Releases the lock
	 */
	public synchronized void unlock(){
		if(Thread.currentThread()==lockedBy){
			lockedCount--;
			if(lockedCount==0){
				System.out.println(Thread.currentThread().getName() +
						" released the lock @ "+ System.nanoTime());
				lockedBy=null;
				isLocked = false;
				notify();
			}
		}
	}
}
