package polytech.tours.di.parallel.td1.exo3;

import java.util.ConcurrentModificationException;

/**
 * Implements a simple counter
 * @author Jorge E. Mendoza (dev@jorge-mendoza.com)
 * @version %I%, %G%
 *
 */
public class Counter{
	
	//the lock
	private Lock lock;
	
	//class constructor
	public Counter(){
		this.lock=new Lock();
	}
	
	/**
	 * The count
	 */
	private int count=0;
	
	/**
	 * Increments the counter
	 */
	public void inc(){
		try{
			lock.lock();
			count++;
		}catch (InterruptedException e){
			throw new ConcurrentModificationException();
		}finally{
			lock.unlock();
		}
	}
	/**
	 * Decrements the counter
	 */
	public void dec(){
		try{
			lock.lock();
			count--;
		}catch (InterruptedException e){
			throw new ConcurrentModificationException();
		}finally{
			lock.unlock();
		}
	}
	/**
	 * 
	 * @return the count
	 */
	public int getCount(){
		return this.count;
	}

}
