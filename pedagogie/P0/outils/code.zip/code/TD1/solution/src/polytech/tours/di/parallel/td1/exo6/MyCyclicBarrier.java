package polytech.tours.di.parallel.td1.exo6;

/**
 * Simple (and incomplete) implementation of a cyclic barrier
 * @author Jorge E. Mendoza (dev@jorge-mendoza.com)
 * @version %I%, %G%
 *
 */
public class MyCyclicBarrier implements CyclicBarrier {

	/** The total number of parties (threads) */
	private final int parties;
	/** The number of parties yet to arrive */
	private int count;
	/** The action to execute when the barrier is tripped */
	private Runnable barrierAction;

	//EXO 1: class constructor
	public MyCyclicBarrier(int parties, Runnable barrierAction){
		if (parties <= 0) throw new IllegalArgumentException(); //Bonus +1
		this.parties=parties;
		this.count=parties;
		this.barrierAction=barrierAction;
	}

	//EXO 2: await method
	/* (non-Javadoc)
	 * @see U0111.CyclickBarrier#await()
	 */
	@Override
	public synchronized void await() throws InterruptedException{

		//decrements awaiting parties by 1.
		count--;
		//If the current thread is not the last to arrive, thread will wait.
		if(count>0){
			wait();
		}
		/*If the current thread is last to arrive, 
		 *notify all waiting threads, and run the action*/
		else{
			/* All parties have arrive, make reset the counter
			 * so that MyCyclicBarrier could become cyclic. */
			count=parties;
			barrierAction.run(); //run barrier action
			notifyAll(); //notify all waiting threads				
		}

	}

	//EXO4: getNumberWaiting
	/* (non-Javadoc)
	 * @see U0111.CyclickBarrier#getNumberWaiting()
	 */
	@Override
	public synchronized int getNumberWaiting(){
		return parties - count;
	}

	//EXO4: getParties();
	/* (non-Javadoc)
	 * @see U0111.CyclickBarrier#getParties()
	 */
	@Override
	public int getParties(){
		return this.parties;
	}

}
