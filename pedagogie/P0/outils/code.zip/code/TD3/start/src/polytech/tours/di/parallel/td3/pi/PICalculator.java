package polytech.tours.di.parallel.td3.pi;

/**
 * Implements the "master tasks"
 * @author Jorge E. Mendoza (dev@jorge-mendoza.com)
 * @version %I%, %G%
 *
 */
public class PICalculator {

	public double computePI(long runs, int nbThreads, int nbTasks){
		return Double.NaN;
	}
}
