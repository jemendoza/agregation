package polytech.tours.di.parallel.td3.pi;

import java.util.concurrent.Callable;

/**
 * Implements an estimation of PI using simulation
 * @author Jorge E. Mendoza (dev@jorge-mendoza.com)
 * @version %I%, %G%
 *
 */
public class PIComputation implements Callable<Long> {

	@Override
	public Long call() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}
		
	
}
