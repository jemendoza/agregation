package polytech.tours.di.parallel.td3.pi;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
/**
 * Provides services for estimating the value of PI using monte-carlo simulation
 * @author Jorge E. Mendoza (dev@jorge-mendoza.com)
 * @version %I%, %G%
 *
 */
public class PICalculator {
	/**
	 * Estimates the value of PI using monte-carlo simulation and parallel computing. The approach follows:
	 * <ul>
	 * <li>Inscribe a circle in a 1x1 square</li>
	 * <li>Randomly generate <code>runs</code> points in the square</li>
	 * <li>Determine the number of points in the square that are also in the circle</li>
	 * <li>Let <code>p</code> be the number of points in the circle divided by the number 
	 * of points in the square, then <code>\pi \approx 4 \times p</code>
	 * 
	 * The problem is decomposed into tasks as follows. Each task consists on generating  a given number of points
	 * and evaluating if they lay (or not) in the circle. The number of points that each task
	 * generates is called the task size. The number of tasks is a parameter.
	 * 
	 * Tasks are executed in multiple threads. The task to thread mapping strategy is dynamic and managed
	 * by a {@link ExecutorService}. The number of available threads is a parameter.
	 * 
	 * @param runs the number of points to simulate
	 * @param nbThreads the number of threads to use
	 * @param nbTasks the number of tasks. Each task has a "size" of <code>runs/nbTasks</code>
	 * @return an estimation of PI
	 */
	public double computePI(long runs, int nbThreads, int nbTasks){

		//Instantiate a service executor
		ExecutorService executor = Executors.newFixedThreadPool(nbThreads);
		//Initialize auxiliary variables
		List<Future<Long>> results;
		List<Callable<Long>> tasks=new ArrayList<Callable<Long>>();
		//Create the nbTasks and store them on a list
		for(int t=1; t<=nbTasks; t++){
			tasks.add(new PIComputation(runs/nbTasks,1));
		}
		try {
			//Ask the executor to execute the tasks and store the results on a list
			results=executor.invokeAll(tasks);
			executor.shutdown();
		} catch (InterruptedException e) {
			return Double.NaN;
		}
		//Compute PI
		try {
			long counter=0l;
			for(Future<Long> t:results){
				counter=counter+t.get();
			}
			return 4d * ((double)counter/runs);
		}
		catch (InterruptedException | ExecutionException e) {
			return Double.NaN;
		}
	}	

}
