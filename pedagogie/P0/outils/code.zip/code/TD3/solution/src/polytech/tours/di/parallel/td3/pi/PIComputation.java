package polytech.tours.di.parallel.td3.pi;

import java.util.concurrent.Callable;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Implements a parallel tasks that estimates PI using simulation
 * @author Jorge E. Mendoza (dev@jorge-mendoza.com)
 * @version %I%, %G%
 *
 */
public class PIComputation implements Callable<Long> {
	//replications
	private long runs;
	//circle diameter
	private int d;
	//the in-the-circle points counter
	private long count;
	//the x coordinate of the circle/square center
	private double ox;
	//the y coordinate of the circle/square center
	private double oy;
	/**
	 * Constructs a new PIComputation
	 * @param runs the "size" of the task, that is, the number of runs (simulated points) for which the task is responsible.
	 * @param d the diameter of the circle (or the side of the square)
	 */
	public PIComputation(long runs, int d){
		this.runs=runs;
		this.d=d;
		ox=d/2d;
		oy=d/2d;
	}
	
	@Override
	public Long call() throws Exception {
		count=0l;
		for(int i=1; i<=runs; i++){
			double px=ThreadLocalRandom.current().nextDouble(d);
			double py=ThreadLocalRandom.current().nextDouble(d);
			if(inCircle(px,py))
				count++;
		}
		return count;
	}
	/**
	 * 
	 * @param cx the x coordinate of a point
	 * @param cy the y coordinate of a point
	 * @return true if the point <code>(cx,cy)</code> is insie the circle, false otherwise
	 */
	private boolean inCircle(double cx, double cy){
		return euclidean(cx,cy,ox,oy)<=d/2d;
	}
	/**
	 * 
	 * @param cx1 the x coordinate of the first point
	 * @param cy1 the y coordinate of the first point
	 * @param cx2 the x coordinate of the second point
	 * @param cy2 the y coordinate of the second point
	 * @return the Euclidean distance between point <code>(cx1,cy1)</code> and point <code>(cx2,cy2)</code>   
	 */
	private double euclidean(double cx1, double cy1, double cx2, double cy2){
		return Math.sqrt(Math.pow(cx1-cx2, 2)+Math.pow(cy1-cy2, 2));
	}
	
}
