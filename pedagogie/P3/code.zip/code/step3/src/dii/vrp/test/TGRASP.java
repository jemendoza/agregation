package dii.vrp.test;


import java.util.Random;

import dii.vrp.data.IDemands;
import dii.vrp.data.IDistanceMatrix;
import dii.vrp.data.VRPREPInstanceReader;
import dii.vrp.solver.ExplorationStrategy;
import dii.vrp.solver.GRASP;
import dii.vrp.solver.NNHeuristic;
import dii.vrp.solver.OptimizationCriterion;
import dii.vrp.solver.Relocate;
import dii.vrp.solver.SFRSHeuristic;
import dii.vrp.solver.Split;
import dii.vrp.solver.VND;
import dii.vrp.solver.VRPSolution;

public class TGRASP {

	public static void main(String[] args) {

		//Parameters
		//Instance
		String file= "./data/christofides-et-al-1979-cmt/CMT01.xml";
		int T=1000;
		
		//Read data from an instance file
		IDistanceMatrix distances=null;
		IDemands demands=null;
		double Q=Double.NaN;
		try(VRPREPInstanceReader parser=new VRPREPInstanceReader(file)){
			distances=parser.getDistanceMatrix();
			demands=parser.getDemands();
			Q=parser.getCapacity("0");
		}
			
		//Set up GRASP
		NNHeuristic nn=new NNHeuristic(distances);
		Split split=new Split(distances, demands, Q);
		SFRSHeuristic h=new SFRSHeuristic(nn, split);
		h.setRandomized(true);
		h.setRandomizationFactor(3);
		h.setRandomGen(new Random(1));
		Relocate relocate=new Relocate(distances, demands, Q);
		relocate.setExplorationStrategy(
				ExplorationStrategy.FIRST_IMPROVEMENT);
		VND vnd=new VND(relocate);
		GRASP grasp=new GRASP(h, vnd, T);
		
		//Run GRASP
		VRPSolution s=(VRPSolution)grasp.run(null,
				OptimizationCriterion.MINIMIZATION);
		
		//Report solution
		System.out.println(s);
		
	}

}
