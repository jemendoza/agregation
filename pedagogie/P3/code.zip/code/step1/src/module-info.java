module vrp_tp2_sol {
	exports dii.vrp.solver;
	exports dii.vrp.data;
	exports dii.vrp.util;
	exports dii.vrp.test;

	requires java.xml;
	requires jdom;
}