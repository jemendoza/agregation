package dii.vrp.solver;

/**
 * Models a VRP solution
 * @author Jorge E. Mendoza (dev@jorge-mendoza.com)
 * @version %I%, %G%
 * @since Jan 21, 2016
 *
 */
public class VRPSolution implements ISolution {

	//TODO EXO1: Complete the implementation of this class
	
	@Override
	public double getOF() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void setOF(double of) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public ISolution clone() {
		// TODO Auto-generated method stub
		return null;
	}
	
	
	
	
}
