package dii.vrp.solver;

import dii.vrp.data.IDemands;
import dii.vrp.data.IDistanceMatrix;

/**
 * Implements a basic split procedure. The implementation assumes that the {@link TSPSolution} passed to method {@link #split(TSPSolution)} contains 
 * the depot at the begining and end of the route.
 * 
 * @author Jorge E. Mendoza (dev@jorge-mendoza.com)
 * @version %I%, %G%
 * @since Jan 21, 2016
 *
 */
public class Split implements ISplit {
	/**
	 * The distance matrix
	 */
	private final IDistanceMatrix distances;
	/**
	 * The customer demands
	 */
	private final IDemands demands;
	/**
	 * The vehicle's capacity
	 */
	private final double Q;

	/**
	 * 
	 * @param distances
	 * @param demands
	 * @param Q
	 */
	public Split(IDistanceMatrix distances, IDemands demands, double Q){
		this.distances=distances;
		this.demands=demands;
		this.Q=Q;
	}

	@Override
	public ISolution split(TSPSolution r) {

		//TODO EXO2: We will implement the algorithm together

		return extractRoutes();
	}
	/**
	 * Extracts the routes from the labels, builds a solution, and evaluates the solution
	 * @return a solution with the routes in the optimal partition of the TSP tour
	 */
	private VRPSolution extractRoutes(){
		
		//TODO EXO2: implement this method
		
		return null;
	}

}
