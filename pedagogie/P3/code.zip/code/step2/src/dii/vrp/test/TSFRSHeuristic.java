package dii.vrp.test;

import dii.vrp.data.IDemands;
import dii.vrp.data.IDistanceMatrix;
import dii.vrp.data.VRPREPInstanceReader;
import dii.vrp.solver.ISplit;
import dii.vrp.solver.ITSPHeuristic;
import dii.vrp.solver.NNHeuristic;
import dii.vrp.solver.SFRSHeuristic;
import dii.vrp.solver.Split;

public class TSFRSHeuristic {

	public static void main(String[] args) {
		String file="./data/christofides-et-al-1979-cmt/CMT01.xml";
		
		//Read data from file
		IDistanceMatrix distances=null;
		IDemands demands=null;
		double Q=Double.NaN;
		try(VRPREPInstanceReader parser=new VRPREPInstanceReader(file))
		{
			distances=parser.getDistanceMatrix();
			demands=parser.getDemands();
			Q=parser.getCapacity("0")
;		}
		
		//Set up the heuristic
		ITSPHeuristic rnn=new NNHeuristic(distances);
		ISplit s=new Split(distances,demands,Q);
		SFRSHeuristic h=new SFRSHeuristic(s,rnn);
		
		//Run the heuristic
		System.out.println(h.run());
	}

}
