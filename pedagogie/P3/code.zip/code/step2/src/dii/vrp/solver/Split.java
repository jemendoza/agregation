package dii.vrp.solver;

import dii.vrp.data.IDemands;
import dii.vrp.data.IDistanceMatrix;

/**
 * Implements a basic split procedure. The implementation assumes that the 
 * {@link TSPSolution} passed to method {@link #split(TSPSolution)} contains 
 * the depot at the begining and end of the route.
 * 
 * @author Jorge E. Mendoza (dev@jorge-mendoza.com)
 * @version %I%, %G%
 * @since Jan 21, 2016
 *
 */
public class Split implements ISplit {
	/**
	 * The distance matrix
	 */
	private final IDistanceMatrix distances;
	/**
	 * The customer demands
	 */
	private final IDemands demands;
	/**
	 * The vehicle's capacity
	 */
	private final double Q;

	/**
	 * 
	 * @param distances
	 * @param demands
	 * @param Q
	 */
	public Split(IDistanceMatrix distances, IDemands demands, double Q){
		this.distances=distances;
		this.demands=demands;
		this.Q=Q;
	}

	@Override
	public ISolution split(TSPSolution r) {

		//Define and Initialize labels
		int[] P=new int[r.size()-1];
		//stores the predecessor labels
		double[] V=new double[r.size()-1];
		//stores the shortest path labels

		for(int i=1; i<r.size()-1;i++){
			V[i]=Double.MAX_VALUE;
		}

		//Build the auxiliary graph and find the shortest path
		for(int i=1;i<r.size();i++){
			//Evaluate all the arcs starting at node i

			//Initialize route metrics
			double load=0;
			double cost=0;

			//Build the arcs
			int j=i;
			while(load<=Q&&j<r.size()-1){
				//Compute metrics for the route
				load+=demands.getDemand(r.get(j));
				//the load of the route
				if(i==j)
					cost=distances.getDistance(0,r.get(j))+
					distances.getDistance(r.get(j),0);
				else
					cost=cost-
					distances.getDistance(r.get(j-1),0)+
					distances.getDistance(r.get(j-1),
							r.get(j))+
					distances.getDistance(r.get(j),0);

				//Check if the arc (route) is feasible
				if(load<=Q){
					if(V[i-1]+cost<V[j]){
						V[j]=V[i-1]+cost;
						P[j]=i-1;
					}
					j++;
				}
			}
		}

		return extractRoutes(P,V,r);
	}
	/**
	 * Extracts the routes from the labels, builds a solution, 
	 * and evaluates the solution 
	 * @return a solution with the routes in the optimal partition 
	 * of the TSP tour
	 */
	private VRPSolution extractRoutes(int[] P, double[] V, TSPSolution tsp){

		VRPSolution s=new VRPSolution();
		double of=0;
		int head=P.length-1;
		int nodesToRoute=P.length-1;
		while(nodesToRoute>0){
			int tail=P[head]+1;
			VRPRoute r=new VRPRoute();
			r.add(0);
			double load=0;
			for(int i=tail;i<=head;i++){
				int node=tsp.get(i);
				r.add(node);
				load+=demands.getDemand(node);
				nodesToRoute--;
			}
			r.add(0);
			double cost=V[head]-V[P[head]];
			of+=cost;
			r.setLoad(load);
			s.addRoute(r);
			head=P[head];			
		}
		s.setOF(of);
		return s;
	}

}
