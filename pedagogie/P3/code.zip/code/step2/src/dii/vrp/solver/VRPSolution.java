package dii.vrp.solver;

import java.util.ArrayList;
import java.util.List;

/**
 * Models a VRP solution
 * @author Jorge E. Mendoza (dev@jorge-mendoza.com)
 * @version %I%, %G%
 * @since Jan 21, 2016
 *
 */
public class VRPSolution implements ISolution {
	/**
	 * The list of routes
	 */
	private List<IRoute> routes;
	/**
	 * The objective function
	 */
	private double of=Double.NaN;
	
	public VRPSolution(){
		this.routes=new ArrayList<>();
	}
	
	@Override
	public double getOF() {
		return this.of;
	}

	@Override
	public void setOF(double of) {
		this.of=of;		
	}

	@Override
	public ISolution clone() {
		VRPSolution clone=new VRPSolution();
		clone.routes=this.cloneRoutes();
		clone.of=this.of;
		return clone;
	}
	
	/**
	 * Clones the list of routes
	 * @return
	 */
	private List<IRoute> cloneRoutes(){
		List<IRoute> clone=new ArrayList<>();
		for(IRoute r:this.routes)
			clone.add(r.clone());
		return clone;
	}
	/**
	 * 
	 * @return the number of routes in the solution
	 */
	public int size(){
		return this.routes.size();
	}
	/**
	 * 
	 * @return a copy of the list of routes
	 */
	public List<IRoute> getRoutes(){
		return this.cloneRoutes();
	}
	
	public void addRoute(final IRoute r){
		this.routes.add(r.clone());
	}
	
	public void insertRoute(final IRoute r, int i){
		this.routes.set(i, r.clone());
	}
	
	@Override
	public String toString(){
		StringBuilder sb=new StringBuilder();
		sb.append(this.of+"\n");
		for(IRoute r:routes){
			sb.append(r.toString()+"\n");
		}
		return sb.toString();
	}
	
}
