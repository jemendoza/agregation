package dii.vrp.solver;

public class SFRSHeuristic implements IOptimizationAlgorithm {
	/**
	 * The split algorithm
	 */
	private final ISplit s;
	/**
	 * The TSP heuristic
	 */
	private final ITSPHeuristic h;
	
	public SFRSHeuristic(ISplit s, ITSPHeuristic h){
		this.s=s;
		this.h=h;
	}
	
	@Override
	public ISolution run() {
		return s.split(h.run());
	}

}
