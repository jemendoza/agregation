#include <sys/types.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>

int main(void)
{
	//Auxiliary variables
    pid_t pid1, pid2;
	int tube[2], ret;
	char buff[20];
    
	//Create tube
    pipe(tube);
	
	pid1 = fork();
    //Create child 1
	if(pid1 == 0)
	{
		close(tube[0]);
		write(tube[1], "Message from child 1\n", 21);
		close(tube[1]);
		exit(EXIT_SUCCESS);
	}
    //Create child 2
	pid2 = fork();
	if(pid2 == 0)
	{
		close(tube[0]);
		write(tube[1], "Message from child 2\n", 21);
		close(tube[1]);
		exit(EXIT_SUCCESS);
	}

	close(tube[1]);
	
	//Read messages sent by the children
	while((ret = read(tube[0], buff, 20)) != 0)
		write(1, buff, ret);
		
	close(tube[0]);
    
	printf("%d\n",PIPE_BUF);
    
	return 0;
}

