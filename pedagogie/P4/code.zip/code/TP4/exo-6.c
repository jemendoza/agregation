#include <sys/types.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>

int main(void)
{
    //Auxiliary variables
	pid_t pid1, pid2;
	int tube1[2], tube2[2], i, ret1 = 1, ret2 = 1;
	char buff[20];
	
    //Create pipe 1
	pipe(tube1);
    
    //Create child 1
	pid1 = fork();
	if(pid1 == 0)
	{
		//Child 1
		close(tube1[0]);
		
		for(i = 0; i < 5; i++)
		{
			sleep(1);
			write(tube1[1], "Message from child 1\n", 21);
		}
		
		close(tube1[1]);
        exit(EXIT_SUCCESS);
	}
    
    //Create pipe 2
	pipe(tube2);
    //Create child 2
	pid2 = fork();
	if(pid2 == 0)
	{
		//Child 2
		close(tube2[0]);
		
		for(i = 0; i < 5; i++)
		{
			sleep(1);
			write(tube2[1], "Message from child 2\n", 23);
		}
				
		close(tube2[1]);
        exit(EXIT_SUCCESS);
	}
    
    //Parent's code
    
    //Close unused fds
	close(tube1[1]);
	close(tube2[1]);

	//Setting non blocking reading for the tubes
	fcntl(tube1[0], F_SETFL, O_NONBLOCK);
	fcntl(tube2[0], F_SETFL, O_NONBLOCK);

	while(ret1 != 0 && ret2 != 0)
	{
		//Read messages from child 1
		while((ret1 = read(tube1[0], buff, 20)) != 0 && ret1 != -1)
			write(1, buff, ret1);
		
		//Read messages from child 2
		while((ret2 = read(tube2[0], buff, 20)) != 0 && ret2 != -1)
			write(1, buff, ret2);
	
	}
	
    //Clean the house
	close(tube1[0]);
	close(tube2[0]);
	
	exit(EXIT_SUCCESS);
}

