#include <sys/types.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <errno.h>

int main(void){
    //Auxiliary variables
    pid_t pid;
    
    //Create child process
    pid=fork();
    
    if(pid==0){
        //Child's code
        printf("CHILD: still printing to the console\n");
        //Open file
        int fd=open("output.txt", O_RDWR|O_CREAT, S_IRWXU);
        //Redirect the std output
        if(dup2(fd,1)==-1){
            perror("dup2");
            exit(errno);
        }
        //Close unused fds
        close(fd);
        //Print to file
        printf("CHILD: now printing to file\n");
        exit(EXIT_SUCCESS);
        
    }
    
    //Parent's code
    exit(EXIT_SUCCESS);
}


