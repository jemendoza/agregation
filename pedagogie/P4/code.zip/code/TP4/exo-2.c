#include <sys/types.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <errno.h>

int main(void){
    //Auxiliary variables
    pid_t pid;
    int tube[2];
    char buf[50];
    
    //Set up pipe
    pipe(tube);
    
    //Create child process
    pid=fork();
    
    if(pid==0){
        //Child's code
        
        //Close unused fds
        close(tube[0]);
        
        //Short pause (simulates a long computation)
        sleep(3);
        
        //Send a message to the parent
        write(tube[1], "This is a message from the child",34);
        printf("CHILD: message sent\n");
        
        //Close fds
        close(tube[1]);
        
        exit(EXIT_SUCCESS);
        
    }
    
    //Parent's code
    
    //Close unused fds
    close(tube[1]);
    
    //Read message from the child
    read(tube[0],buf,34);
    printf("PARENT: message read -- %s --\n",buf);
    
    //Close fds
    close(tube[0]);
    
    exit(EXIT_SUCCESS);
}


