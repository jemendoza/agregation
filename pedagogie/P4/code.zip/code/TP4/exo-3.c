#include <sys/types.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <errno.h>

int main(void){
    //Auxiliary variables
    pid_t pid;
    int tube[2];
    char buf[50];
    
    //Set up pipe
    pipe(tube);
    
    //Create child process
    pid=fork();
    
    if(pid==0){
        //Child's code
        
        //Redirect standard output
        close(tube[0]);
        dup2(tube[1],1);
        close(tube[1]);
        
        
        //Short pause (simulates a long computation)
        sleep(3);
        
        //Send a message to the parent
        printf("This is a message from the child\n");
        
        exit(EXIT_SUCCESS);
        
    }
    
    //Parent's code
    
    //Redirect standard input
    close(tube[1]);
    dup2(tube[0],0);
    close(tube[0]);

    
    //Read message from the child
    fgets(buf,34,stdin);
    printf("PARENT: message read %s",buf);
    
    exit(EXIT_SUCCESS);
}


