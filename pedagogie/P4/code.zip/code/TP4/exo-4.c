#include <sys/types.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <errno.h>
#include <string.h>

int main(void){
    //Auxiliary variables
    pid_t pid;
    int tube1[2], tube2[2];
    char buf[50];
    
    //Set up pipe
    pipe(tube1);
    pipe(tube2);
    
    //Create child process
    pid=fork();
    
    if(pid==0){
        //Child's code
        
        //Set up standard output
        close(tube1[0]);
        dup2(1,3); //back up standard output
        dup2(tube1[1],1);
        close(tube1[1]);
        
        //Set up standad input
        close(tube2[1]);
        dup2(tube2[0],0);
        close(tube2[0]);
        
        //Send a message to the parent
        printf("Message from the child\n");
        fflush(stdout);
        
        //Read the message from the parent
        fgets(buf,25,stdin);
        
        //Print the received message to the console
        write(3,"CHILD - message read: ",22);
        write(3,buf,strlen(buf));
        
        //Close fds
        close(3);
        
        exit(EXIT_SUCCESS);
        
    }
    
    //Parent's code
    
    //Redirect standard input
    close(tube1[1]);
    dup2(tube1[0],0);
    close(tube1[0]);
    
    //Redirect standard output
    close(tube2[0]);
    dup2(1,3);
    dup2(tube2[1],1);
    close(tube2[1]);
    
    //Send a message to the child
    printf("Message from the parent\n");
    fflush(stdout);
    
    //Read the message from the child
    fgets(buf,25,stdin);
    
    //Print the received message to screen
    write(3,"PARENT - message read: ",23);
    write(3,buf,strlen(buf));
    
    //Close fds
    close(3);
    
    exit(EXIT_SUCCESS);
}


