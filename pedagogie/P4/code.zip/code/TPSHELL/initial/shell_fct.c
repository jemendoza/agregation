#include "shell_fct.h"

int exec_command(cmd* my_cmd){
    //Your implementation comes here
    return 0; //your return code goes here
}