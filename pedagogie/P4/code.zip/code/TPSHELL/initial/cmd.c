#include "cmd.h"

//Prints the command
void printCmd(cmd *cmd){
	//your implementation comes here
}

//Initializes the initial_cmd, membres_cmd et nb_membres fields
void parseMembers(char *inputString,cmd *cmd){
    //Your implementation comes here
}

//Frees memory associated to a cmd
void freeCmd(cmd  * cmd){
  
}
