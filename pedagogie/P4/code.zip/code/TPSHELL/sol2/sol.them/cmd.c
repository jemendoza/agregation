#include "cmd.h"

/*
returns str with the wrapping blank space removed. String has been allocated on the stack
*/
char * removeWrappingBlankSpace(char * str, int idx)
{
	int begws, endws, i = 0;
	int len = strlen(str);
	char * newstr;

	//to not have valgrind error if str is just a blank string
	if(strncmp(" ", str, 1) == 0 && !idx)
		return strdup("\0");
	
	//we count the spaces before the first non-blank character
	while(str[i++] == ' ');
	begws = i - 1;

	i = 0;
	//then we count the spaces after the first non-blank character
	while(str[len - i++ - 1] == ' ');
	endws = i - 1;
	
	newstr = (char *) malloc(sizeof(char) * (len - begws - endws + 1));
	if(newstr == NULL)
		exit(-1);

	//we copy str into newstr from begws to len - endws
	for(i = begws; i < len - endws; i++)
		newstr[i - begws] = str[i];
	newstr[len - begws - endws] = '\0';

	return newstr;
}

void aff_membres_args(cmd *c)
{
	int i, j;

	for(i = 0; i < c->nb_cmd_membres; i++)
	{
		printf("The arguments of the member[%d] \"%s\" are :\n", i, c->cmd_membres[i]);
		for(j = 0; j < c->nb_membres_args[i]; j++)
		{
			printf("arg[%d] = \t\"%s\"\n", j, c->cmd_membres_args[i][j]);
		}
	}
}

void free_membres_args(cmd *c)
{
	int i, j;

	for(i = 0; i < c->nb_cmd_membres; i++)
	{
		for(j = 0; j < c->nb_membres_args[i]; j++)
		{
			free(c->cmd_membres_args[i][j]);
		}

		free(c->cmd_membres_args[i]);
	}

	free(c->nb_membres_args);
	free(c->cmd_membres_args);
}

void parse_membres_args(cmd *c)
{
	int i;
	c->cmd_membres_args = NULL;

	c->cmd_membres_args = (char ***) malloc(sizeof(char **) * (c->nb_cmd_membres + 1));
	if(c->cmd_membres_args == NULL)
		exit(-1);

	c->nb_membres_args = (unsigned int *) malloc(sizeof(unsigned int) * c->nb_cmd_membres);
	if(c->nb_membres_args == NULL)
		exit(-1);

	//For each member we parse its arguments
	for(i = 0; i < c->nb_cmd_membres; i++)
	{
		unsigned int nbArgs = 0;
		//we duplicate c->cmd_membres[i] to not have strtok modifying it
		char * toBeModified = strdup(c->cmd_membres[i]);
		char * tok = strtok(toBeModified, " ");

		c->cmd_membres_args[i] = NULL;
		//for each argument of the member we add it to cmd_membres_args[i]

		while(tok != NULL)
		{
			//if tok is <, >, >>, 2>f or 2>>f then we break
			if(is_stream_separator(tok))
				break;

			nbArgs++;
			
			c->cmd_membres_args[i] = (char **) realloc(c->cmd_membres_args[i], sizeof(char *) * (nbArgs + 1));
			if(c->cmd_membres_args[i] == NULL)
				exit(-1);

			//we also duplicate tok because it will be desallocated when toBeModified will be deallocated.
			c->cmd_membres_args[i][nbArgs - 1] = strdup(tok);
			tok = strtok(NULL, " ");
		}
		//we add NULL to the end of the args array if there is one (no segmentation error)
		if(nbArgs != 0)
			c->cmd_membres_args[i][nbArgs] = NULL;
		c->nb_membres_args[i] = nbArgs;
		free(toBeModified);
	}
	
}

//str will not be modified by this function
void parse_membres(char * str,cmd * ma_cmd)
{
	unsigned int nbmemb = 0;
	char * toBeModified = strdup(str);
	char * tok = strtok(toBeModified, "|");

	ma_cmd->cmd_membres = NULL;
	
	//each iteration strtok will return a new member of the command. For each new command we reallocated
	//ma_cmd->cmd_membres for it to be able to contain the new member
	while(tok != NULL)
	{
		nbmemb++;
		ma_cmd->cmd_membres = (char **) realloc(ma_cmd->cmd_membres, sizeof(char *) * nbmemb);
		if(ma_cmd->cmd_membres == NULL)
			exit(-1);

		ma_cmd->cmd_membres[nbmemb - 1] = removeWrappingBlankSpace(tok, nbmemb - 1);
		//We don't need to free tok because strtok does not allocated
		tok = strtok(NULL, "|");
	}

	ma_cmd->nb_cmd_membres = nbmemb;
	free(toBeModified);
}

void aff_membres(cmd *ma_cmd)
{
	int i;

	for(i = 0; i < ma_cmd->nb_cmd_membres; i++)
		printf("Le membre %d est : \"%s\"\n", i, ma_cmd->cmd_membres[i]);
}

void free_membres(cmd *ma_cmd)
{
	int i;

	for(i = 0; i < ma_cmd->nb_cmd_membres; i++)
		free(ma_cmd->cmd_membres[i]);

	free(ma_cmd->cmd_membres);
}

//We assume that the stream character is immediately followed by the file name (no space inbetween)
void parse_redirection(cmd *c)
{
	int mode, i;

	//we allocate all needed structures
	c->redirection = (char ***) malloc(sizeof(char**) * c->nb_cmd_membres);
	if(c->redirection == NULL)
		exit(-1);

	c->type_redirection = (int **) malloc(sizeof(int*) * c->nb_cmd_membres);
	if(c->type_redirection == NULL)
		exit(-1);

	for(i = 0; i < c->nb_cmd_membres; i++)
	{
		c->redirection[i] = (char **) malloc(sizeof(char *) * 3);
		if(c->redirection[i] == NULL)
			exit(-1);

		c->type_redirection[i] = (int *) malloc(sizeof(int) * 3);
		if(c->type_redirection[i] == NULL)
			exit(-1);

		c->redirection[i][STDIN] = NULL;
		c->redirection[i][STDOUT] = NULL;
		c->redirection[i][STDERR] = NULL;

		c->type_redirection[i][STDIN] = 0;
		c->type_redirection[i][STDOUT] = 0;
		c->type_redirection[i][STDERR] = 0;
	}


	//for each member we parse the redirection..
	//if the member is neither the first nor the last, then we only try to parse 2> and 2>> type redirections

	for(i = 0; i < c->nb_cmd_membres; i++)
	{
		char * toBeModified = strdup(c->cmd_membres[i]);
		char * tok = strtok(toBeModified, " ");

		//we advance to the next stream separator
		while(tok != NULL && !is_stream_separator(tok))
			tok = strtok(NULL, " ");


		//while tok is still a stream operator
		while(tok != NULL && is_stream_separator(tok))
		{
			//here tok is the next stream separator
			int offset;
			mode = get_redirection_mode(tok, &offset);

			if(i > 0 && mode == 2)
			{
				printf("Error - there can only be a STDIN redirections on the first member (in member \"%s\", token \"%s\")\n", c->cmd_membres[i], tok);
				break;
			}
			if(i < c->nb_cmd_membres - 1 && (mode == 0 || mode == 1))
			{
				printf("Error - there can only be a STDOUT redirections on the last member (in member \"%s\", token \"%s\")\n", c->cmd_membres[i], tok);
				break;
			}

			//case 0 and 3 don't have break because if there's an append type redirection then there's a redirection
			switch(mode)
			{
				case 0:
					c->type_redirection[i][STDOUT] = APPEND;
				case 1:
					c->redirection[i][STDOUT] = strdup(tok + offset);
					break;
				case 2:
					c->redirection[i][STDIN] = strdup(tok + offset);
					break;
				case 3:
					c->type_redirection[i][STDERR] = APPEND;
				case 4:
					c->redirection[i][STDERR] = strdup(tok + offset);
					break;
				default:
					printf("Fatal error : \"%s\" is not a stream separator.", tok);
					exit(-1);
			}


			//and now tok contains the path of redirection or tok is NULL if there's no redirection anymore
			tok = strtok(NULL, " ");
		}

		free(toBeModified);
	}

}

void free_redirection(cmd *c)
{
	int i;

	for(i = 0; i < c->nb_cmd_membres; i++)
	{
		free(c->redirection[i][STDOUT]);
		free(c->redirection[i][STDIN]);
		free(c->redirection[i][STDERR]);

		free(c->redirection[i]);
		free(c->type_redirection[i]);
	}

	free(c->redirection);
	free(c->type_redirection);
}

void aff_redirection(cmd * c, int i)
{
	printf("Redirection on member \"%s\"\n", c->cmd_membres[i]);

	if(c->redirection[i][STDOUT] != NULL)
		printf("On STDOUT : \"%s\" is redirected to %s (mode : %d)\n", c->cmd_membres[i], c->redirection[i][STDOUT], c->type_redirection[i][STDOUT]); 
	if(c->redirection[i][STDIN] != NULL)
		printf("On STDIN : \"%s\" is redirected to %s\n", c->cmd_membres[i], c->redirection[i][STDIN]); 
	if(c->redirection[i][STDERR] != NULL)
		printf("On STDERR : \"%s\" is redirected to %s (mode : %d)\n", c->cmd_membres[i], c->redirection[i][STDERR], c->type_redirection[i][STDERR]);
	if(c->redirection[i][STDOUT] == NULL &&
		c->redirection[i][STDERR] == NULL &&
		c->redirection[i][STDIN] == NULL)
		printf("There is no redirection !\n");
}

/*
the modes are :
0 : stdout - append
1 : stdout - create
2 : stdin
3 : stderr - append
4 : stderr - create

This function returns the mode according to the stream separator, and the amounts of bytes to offset to get the redirect file
*/
int get_redirection_mode(char * tok, int * offset)
{
	int mode = -1;

	if(strncmp("2>>", tok, 3) == 0)
	{
		mode = 3;
		*offset = 3;
	}
	else if(strncmp("2>", tok, 2) == 0)
	{
		mode = 4;
		*offset = 2;
	}
	else if(strncmp(">>", tok, 2) == 0)
	{
		mode = 0;
		*offset = 2;
	}
	else if(strncmp(">", tok, 1) == 0)
	{
		mode = 1;
		*offset = 1;
	}
	else if(strncmp("<", tok, 1) == 0)
	{
		mode = 2;
		*offset = 1;
	}

	return mode;
}

int is_stream_separator(char * tok)
{
	int trash;
	return (get_redirection_mode(tok, &trash) != -1);
}
