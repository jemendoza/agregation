#include "shell_fct.h"

pid_t current_pid = -1;

//SIGALRM signal handler
void on_alarm(int sig)
{
	//we kill current child
	printf("Le programme ne répond pas. Arrêt du programme !\n");
	kill(current_pid, SIGKILL);
}

int error_management(cmd * ma_cmd)
{
	int error = 0;

	//check if the command start by a pipe or by nothing
	if(ma_cmd->cmd_membres == NULL)
	{
		printf("Erreur, ne pas commencer une commande par un pipe ('|').\n");
		error = 1;
	}
	//or if the command start by a blank
	else if(strcmp("", ma_cmd->cmd_membres[0]) == 0)
	{
		printf("Erreur, ne pas commencer une commande par un espace.\n");
		error = 1;
	}
	//or if the command start by a redirection
	else if(strncmp("<", ma_cmd->cmd_membres[0], 1) == 0 ||
	   strncmp(">", ma_cmd->cmd_membres[0], 1) == 0 ||
           strncmp("2>", ma_cmd->cmd_membres[0], 2) == 0)
	{
		printf("Erreur, ne pas commencer une commande par un (ou des) chevron(s) de redirection.\n");
		error = 1;
	}

	return error;
}

int manage_redirection(cmd * ma_cmd, int i)
{
	int fd, flag, inputRedirection = 0;
	int errorInput = 0;

	if(ma_cmd->redirection[i][STDIN] != NULL)
	{
		fd = open(ma_cmd->redirection[i][STDIN], O_RDONLY);

		if (fd == -1)
		{
			//if the file doesn't exist we write the error in STDOUT but we still keep executing the command
			printf("bash: %s: aucun fichier ou dossier de ce type\n", ma_cmd->redirection[i][STDIN]);
			errorInput = 1;
		}
		else
		{
			dup2(fd, 0);
			//we only close fd if the file exists
			close(fd);
		}

		inputRedirection = 1;
	}
	if(ma_cmd->redirection[i][STDOUT] != NULL)
	{
		//first we try to open the file only on writing
		flag = O_WRONLY;
		fd = open(ma_cmd->redirection[i][STDOUT], flag, 00777);

		if(fd != -1)
		{
			close(fd);
			//if the file exists and there's no append type redirection then we delete the file in order to overwrite the file
			flag |= O_CREAT | (ma_cmd->type_redirection[i][STDOUT] ? O_APPEND : 0);

			if(flag == (O_WRONLY | O_CREAT))
				remove(ma_cmd->redirection[i][STDOUT]);
		}
		else
		{
			//if the file doesn't exists we only change the mode in order to create it
			flag |= O_CREAT | (ma_cmd->type_redirection[i][STDOUT] ? O_APPEND : 0);
		}

		fd = open(ma_cmd->redirection[i][STDOUT], flag, 00777);	
		dup2(fd, 1);
		close(fd);
	}
	//if there's an input redirection we can't have an error redirection
	if(ma_cmd->redirection[i][STDERR] != NULL && !inputRedirection)
	{
		//the same as STDOUT
		flag = O_WRONLY;
		fd = open(ma_cmd->redirection[i][STDERR], flag, 00777);

		if(fd != -1)
		{
			close(fd);
			flag |= O_CREAT | (ma_cmd->type_redirection[i][STDERR] ? O_APPEND : 0);

			if(flag == (O_WRONLY | O_CREAT))
				remove(ma_cmd->redirection[i][STDERR]);
		}
		else
		{
			flag |= O_CREAT | (ma_cmd->type_redirection[i][STDERR] ? O_APPEND : 0);
		}

		fd = open(ma_cmd->redirection[i][STDERR], flag, 00777);	
		dup2(fd, 2);
		close(fd);
	}

	return errorInput;
}

int exec_commande(cmd* ma_cmd)
{
	int * pipe_prev, * pipe_next;
	int i, tube[2][2];
	char buffer[32];

	signal(SIGALRM, on_alarm);

	if(error_management(ma_cmd))
		return MYSHELL_CMD_OK;

	//management of the commands cd and exit
	if(strncmp("exit", ma_cmd->cmd_membres_args[0][0], 4) == 0)
	{
		return MYSHELL_FCT_EXIT;
	}
	else if(strncmp("cd", ma_cmd->cmd_membres_args[0][0], 2) == 0)
	{
		if(ma_cmd->nb_membres_args[0] > 1)
			chdir(ma_cmd->cmd_membres_args[0][1]);

		return MYSHELL_CMD_OK;
	}

	pipe(tube[0]);
	pipe(tube[1]);

/*
   pipe_next <> pipe_prev   pipe_next <> pipe_prev   pipe_next ...
(member) >> pipe[0] >> (member) >> pipe[1] >> (member) >> pipe[0] ...
a member needs both of its surrounding pipes

which tube for which job :

input  : i % 2 == 0 ? 1 : 0
output : i % 2 == 0 ? 0 : 1

tube[i-1][1] and tube[i][0] should be closed at the beginning of each iteration in the child process
	write		read
*/

	for(i = 0; i < ma_cmd->nb_cmd_membres; i++)
	{
		
		int errorInput = 0;
		alarm(5);

		pipe_prev = tube[i % 2 == 0 ? 1 : 0];
		pipe_next = tube[i % 2 == 0 ? 0 : 1];

		current_pid = fork();

		if(current_pid == 0)
		{

			close(pipe_prev[1]);

			//if we are not in the first member, we need to get input from previous member
			if(i != 0)
				dup2(pipe_prev[0], 0);
 
			//we don't need former child's pipes anymore, dup2 is done
			close(pipe_prev[0]);
 
			//everything this process prints will be redirected to pipe_next
			close(pipe_next[0]);
 
			dup2(pipe_next[1], 1);


			//manage redirections
			errorInput = manage_redirection(ma_cmd, i);

			close(pipe_next[1]);

			// If there wasn't an error with the opening of a file we can execute the command
			if(!errorInput)
			{
				execvp(ma_cmd->cmd_membres_args[i][0], ma_cmd->cmd_membres_args[i]);
				perror("execvp");
			}
			
			exit(0);
		}
		else
		{
			if(i == ma_cmd->nb_cmd_membres - 1)
			{
				int fd_stdin;
				
				//we inverse pipe_prev and pipe_next here because child's pipe_next = parent's pipe_next, so when the parent
				//would normally try to read from pipe_prev, it would read from the child's pipe_prev which wouldn't contain anything
				//anymore
				close(pipe_prev[0]);
				close(pipe_prev[1]);

				fd_stdin = dup(0);
				//now that stdin has another fd, we can dup pipe_next[0] to it and it won't be closed.
				dup2(pipe_next[0], 0);

				close(pipe_next[0]);
				close(pipe_next[1]);

				//the pipe is blocking so we will be stuck here until the program outputs something
				while(fgets(buffer, 32, stdin) != NULL)
					printf("%s", buffer);

				dup2(fd_stdin, 0);//we set back stdin
				close(fd_stdin);
			}
			else
			{

				//we reset unneeded pipe because a pipe can only exist between two processes
				//pipe_prev because in the next loop pipe_prev will become pipe_next, which will be
				//the new pipe
				close(pipe_prev[0]);
				close(pipe_prev[1]);
				pipe(pipe_prev);
			}

			// We cancel the last alarm
			alarm(0);
		}
	}

	return MYSHELL_CMD_OK;
}
