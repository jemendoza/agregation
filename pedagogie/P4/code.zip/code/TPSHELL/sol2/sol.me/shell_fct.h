#include "cmd.h"

int exec_commande(cmd* ma_cmd);
