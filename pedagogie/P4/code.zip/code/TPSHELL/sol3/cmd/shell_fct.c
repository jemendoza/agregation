///
/// CONFIDENTIAL
/// Unpublished Copyright (c) 2016 Cédric EMONNEAU & Antoine PECQUET, All Rights Reserved.
///
/// NOTICE:  All information contained herein is, and remains the property of Cédric EMONNEAU and Antoine PECQUET. The intellectual and technical concepts contained
/// herein are proprietary to those autors and may be covered by French author copyright and Foreign Patents, and are protected by trade secret or copyright law.
/// Dissemination of this information or reproduction of this material is strictly forbidden unless prior written permission is obtained
/// from  Cédric EMONNEAU and Antoine PECQUET. Access to the source code contained herein is hereby forbidden to anyone except current people allowed explicitely by
/// Cédric EMONNEAU and Antoine PECQUET.
/// Confidentiality and Non-disclosure agreements explicitly covering such access.
///
/// The copyright notice above does not evidence any actual or intended publication or disclosure  of  this source code, which includes  
/// information that is confidential and/or proprietary, and is a trade secret, of Cédric EMONNEAU and Antoine PECQUET.   ANY REPRODUCTION, MODIFICATION,
/// DISTRIBUTION, PUBLIC  PERFORMANCE, 
/// OR PUBLIC DISPLAY OF OR THROUGH USE  OF THIS  SOURCE CODE  WITHOUT  THE EXPRESS WRITTEN CONSENT OF COMPANY IS STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
/// LAWS AND INTERNATIONAL TREATIES.  THE RECEIPT OR POSSESSION OF  THIS SOURCE CODE AND/OR RELATED INFORMATION DOES NOT CONVEY OR IMPLY ANY RIGHTS  
/// TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT  MAY DESCRIBE, IN WHOLE OR IN PART.                
///

#include "shell_fct.h"
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <signal.h>
#include <sys/file.h>
#include <sys/mman.h>
#include <sys/wait.h>
#include "own_cmd.h"
#include "options.h"



int stillExecuting = 0;
int numberProcessStarted = 0;
pid_t *pidProcessStarted;

//watchdog handler : kill every started process 
void watchdogHandler(int sigNum)
{
  if(sigNum == SIGALRM)
  if(stillExecuting){
    if(pidProcessStarted!=NULL && getWatchdogTimeout() != 0){
      printf("Execution time exeeded %d seconds, aboarding...\n",getWatchdogTimeout());
      int i;
      for(i=0;i < numberProcessStarted;++i){
        if(pidProcessStarted[i]!=0)
          kill(pidProcessStarted[i],SIGKILL);
      }
    }
    
  }
}

int execCommand(cmd* myCmd){
    int tubeIn[3] = {-1,-1,-1};
    int tubeOut[3] = {-1,-1,-1};
    
    int iTube = 0;
    int iProg = 0;
    int realNumberExecutedFork = 0;
    
    stillExecuting = 1;
    
    numberProcessStarted = myCmd->nbCmdMembers;
    if(numberProcessStarted>0){
      pidProcessStarted = malloc(sizeof(pid_t)*myCmd->nbCmdMembers);
    }else
      pidProcessStarted = NULL;
    
    for(iProg = 0;iProg < myCmd->nbCmdMembers;++iProg){
      pidProcessStarted[iProg]=0;
      
      //creating pipes to redirect properly;
      if(iProg+1 < myCmd->nbCmdMembers){
        pipe(tubeOut);
        ++iTube;
      }
      else
      {
        tubeOut[0] = -1;
        tubeOut[1] = -1;
        tubeOut[2] = -1;
      }
      
      if(iProg == 0){//it may be possible to have a file as input
        if(myCmd->redirectionType[iProg][0] > 0)
          tubeIn[0] = open(myCmd->redirection[iProg][0], O_RDONLY);
      }
      if(iProg == myCmd->nbCmdMembers-1){//it may be possible to have a file as input
        if(myCmd->redirectionType[iProg][1] == 2)
          tubeOut[1] = open(myCmd->redirection[iProg][1], O_WRONLY | O_CREAT | O_APPEND,0664);
        else if(myCmd->redirectionType[iProg][1] == 1)
          tubeOut[1] = open(myCmd->redirection[iProg][1], O_WRONLY | O_CREAT | O_TRUNC,0644);
        
        if(myCmd->redirectionType[iProg][2] == 2)
          tubeOut[2] = open(myCmd->redirection[iProg][2], O_WRONLY | O_CREAT | O_APPEND,0664);
        else if(myCmd->redirectionType[iProg][2] == 1)
          tubeOut[2] = open(myCmd->redirection[iProg][2], O_WRONLY | O_CREAT | O_TRUNC,0644);
      }

      
      //looking if the program to start is an intern command or an external program
      char* program = myCmd->cmdMembersArgs[iProg][0];
      char ** args=myCmd->cmdMembersArgs[iProg];
      if(!isCmdShellCmd(program)){
        ++realNumberExecutedFork;
        pid_t newProgram = fork();
        if(newProgram==0){
          
          //pid_t childPid = getpid();
          if(tubeIn[0] != -1){
            dup2(tubeIn[0],0);
            close(tubeIn[1]);
          }
          if(tubeIn[1] != -1){
            close(tubeIn[1]);
          }
          if(tubeOut[0] != -1){
            close(tubeOut[0]);
          }
          if(tubeOut[1] != -1){
            //printf("redirect output");
            dup2(tubeOut[1],1);
            if(tubeOut[2] != -1)
              dup2(tubeOut[2],2);
            else
              dup2(tubeOut[1],2);
            close(tubeOut[1]);
          }
          
          //printf("Pipe in:%d out:%d\n",tubeIn[0],tubeOut[0]);
          
          
          if(!isCmdInternalOutsideProgram(program)){
            execvp(program,args);
            if(errno==ENOENT)
              printf("%s: command not found\n",program);
            else if(errno==EACCES)
              printf("Acces dennied\n");
            else
              printf("Unhandled error number: %s(%d)\n",strerror(errno),errno);
            
            exit(EXIT_SUCCESS);
          }else{
            executeInternalOutsideProgram(program,args);
            exit(EXIT_SUCCESS);
          }
        }else{
          pidProcessStarted[iProg]=newProgram;
          //waitpid(newProgram,NULL,0);
        }
      }else{
        //printf("internam");
        executeShellCmd(program,args);
      }
      
      
      
      //close properly tubes
      if(tubeIn[0] != -1){
        close(tubeIn[0]);
      }
      if(tubeIn[1] != -1){
        close(tubeIn[1]);
      }
      
      tubeIn[0] = tubeOut[0];
      tubeIn[1] = tubeOut[1];
    }
    
    //configure the watchdog 
    if(realNumberExecutedFork>0){
      if(getWatchdogTimeout() != 0){
        signal(SIGALRM,watchdogHandler);
        alarm(getWatchdogTimeout());
      }
      
      //waiting all process to end
      for(iProg = 0;iProg < realNumberExecutedFork;++iProg){
        waitpid(pidProcessStarted[iProg],NULL,0);
      }
      
      if(getWatchdogTimeout() != 0){
        alarm(0);
      }
      
      //telling the execution if finish (so the watchdog know it has nothing to stop)
      stillExecuting = 0;
      
      
      
      free(pidProcessStarted);
    }
    stillExecuting = 0;
    
    
    
    
    return 0; 
} 
