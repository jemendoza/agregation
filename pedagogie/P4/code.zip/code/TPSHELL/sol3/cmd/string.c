///
/// CONFIDENTIAL
/// Unpublished Copyright (c) 2016 Cédric EMONNEAU & Antoine PECQUET, All Rights Reserved.
///
/// NOTICE:  All information contained herein is, and remains the property of Cédric EMONNEAU and Antoine PECQUET. The intellectual and technical concepts contained
/// herein are proprietary to those autors and may be covered by French author copyright and Foreign Patents, and are protected by trade secret or copyright law.
/// Dissemination of this information or reproduction of this material is strictly forbidden unless prior written permission is obtained
/// from  Cédric EMONNEAU and Antoine PECQUET. Access to the source code contained herein is hereby forbidden to anyone except current people allowed explicitely by
/// Cédric EMONNEAU and Antoine PECQUET.
/// Confidentiality and Non-disclosure agreements explicitly covering such access.
///
/// The copyright notice above does not evidence any actual or intended publication or disclosure  of  this source code, which includes  
/// information that is confidential and/or proprietary, and is a trade secret, of Cédric EMONNEAU and Antoine PECQUET.   ANY REPRODUCTION, MODIFICATION,
/// DISTRIBUTION, PUBLIC  PERFORMANCE, 
/// OR PUBLIC DISPLAY OF OR THROUGH USE  OF THIS  SOURCE CODE  WITHOUT  THE EXPRESS WRITTEN CONSENT OF COMPANY IS STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
/// LAWS AND INTERNATIONAL TREATIES.  THE RECEIPT OR POSSESSION OF  THIS SOURCE CODE AND/OR RELATED INFORMATION DOES NOT CONVEY OR IMPLY ANY RIGHTS  
/// TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT  MAY DESCRIBE, IN WHOLE OR IN PART.                
///

#include "string.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

unsigned int countCaracterOutsideString(const char * str, char caracter){
  unsigned int count = 0;
  int inQuote = 0;
  while(*str != '\0'){
    //printf("%c",*str);
    if(*str == '"')
      inQuote = !inQuote;
    
    if(!inQuote && *str == caracter)
      ++count;
    
    ++str;
  }
  return count;
}


unsigned int countCaracterUntilCaracter(const char * str, char caracter){
  unsigned int count = 0;
  int inQuote = 0;
  while(*str != '\0'){
    //printf("%c",*str);
    if(*str == '"')
      inQuote = !inQuote;
    
    if(!inQuote && *str == caracter)
      return count;
    
    ++count;
    
    ++str;
  }
  return count;
}
char * duplicateString(const char * str){
  char * ptr = NULL;
  
  size_t length = strlen(str);
  
  ptr = (char *) malloc ((length + 1) * sizeof(char));
  //if (ptr == NULL)
  //  fatalError ("Memory allocation error in duplicateString.");
  int i;
  for(i=0; i < length+1;++i){
    ptr[i] = str[i];
  }
  
  return ptr; 
  
}
int isStringFullOf(const char * str, char * end, char caract){
  int i;
  for(i = 0; i < strlen(str) && &str[i] != end;++i){
    if(str[i] != caract)
      return 0;
  }
  
  return 1;
}

char * copyStringWithInterval(const char * start, const char * end){
  char * ptr = malloc(sizeof(char)*(end-start+1));
  //printf("allocate:%d\n",(end-start+1));
  //printf("from:%s\n",start);
  int i = 0;
  while(start != end){
    ptr[i]=start[0];
    //printf("copy:%c",*start);
    ++i;
    ++start;
  }
  ptr[i]='\0';
  return ptr;
}
