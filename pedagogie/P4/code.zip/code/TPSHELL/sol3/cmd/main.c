///
/// CONFIDENTIAL
/// Unpublished Copyright (c) 2016 Cédric EMONNEAU & Antoine PECQUET, All Rights Reserved.
///
/// NOTICE:  All information contained herein is, and remains the property of Cédric EMONNEAU and Antoine PECQUET. The intellectual and technical concepts contained
/// herein are proprietary to those autors and may be covered by French author copyright and Foreign Patents, and are protected by trade secret or copyright law.
/// Dissemination of this information or reproduction of this material is strictly forbidden unless prior written permission is obtained
/// from  Cédric EMONNEAU and Antoine PECQUET. Access to the source code contained herein is hereby forbidden to anyone except current people allowed explicitely by
/// Cédric EMONNEAU and Antoine PECQUET.
/// Confidentiality and Non-disclosure agreements explicitly covering such access.
///
/// The copyright notice above does not evidence any actual or intended publication or disclosure  of  this source code, which includes  
/// information that is confidential and/or proprietary, and is a trade secret, of Cédric EMONNEAU and Antoine PECQUET.   ANY REPRODUCTION, MODIFICATION,
/// DISTRIBUTION, PUBLIC  PERFORMANCE, 
/// OR PUBLIC DISPLAY OF OR THROUGH USE  OF THIS  SOURCE CODE  WITHOUT  THE EXPRESS WRITTEN CONSENT OF COMPANY IS STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
/// LAWS AND INTERNATIONAL TREATIES.  THE RECEIPT OR POSSESSION OF  THIS SOURCE CODE AND/OR RELATED INFORMATION DOES NOT CONVEY OR IMPLY ANY RIGHTS  
/// TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT  MAY DESCRIBE, IN WHOLE OR IN PART.                
///

#include <pwd.h>
#include <readline/readline.h>
#include <readline/history.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <unistd.h>
#include "shell_fct.h"
#include "string.h"
#include "options.h"
//To complete
int main(int argc, char** argv)
{
	int ret = MYSHELL_CMD_OK;
	char* readlineptr;
	struct passwd* infos;
	char str[1024];
	char hostname[256];
	char workingdirectory[256];
	
	setWatchdogTimeout(5);
	
	while(ret != MYSHELL_FCT_EXIT)
	{
		//Get your session info
        infos=getpwuid(getuid());
		gethostname(hostname, 256);
		getcwd(workingdirectory, 256);
        //Print it to the console
        // \033 say we want a custom color
        //[0m reset the color to the default one
        // [XX;01m is our custom color (see ANSI escape code)
        // 30->black
        // 31->red
        // ...
		sprintf(str, "\033[31;01m{KSHELL}\033[32;01m%s@%s:\033[34;01m%s$\033[0m ", infos->pw_name, hostname, workingdirectory);
		readlineptr = readline(str);

		if (readlineptr && *readlineptr){
			add_history (readlineptr);
		
		  cmd command;
		  parseMembers(readlineptr,&command);
		  execCommand(&command);
		  freeCmd(&command);
		}
		
		
        
	}
	
	return 0;
}
