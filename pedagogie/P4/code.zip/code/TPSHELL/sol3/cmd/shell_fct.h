///
/// CONFIDENTIAL
/// Unpublished Copyright (c) 2016 Cédric EMONNEAU & Antoine PECQUET, All Rights Reserved.
///
/// NOTICE:  All information contained herein is, and remains the property of Cédric EMONNEAU and Antoine PECQUET. The intellectual and technical concepts contained
/// herein are proprietary to those autors and may be covered by French author copyright and Foreign Patents, and are protected by trade secret or copyright law.
/// Dissemination of this information or reproduction of this material is strictly forbidden unless prior written permission is obtained
/// from  Cédric EMONNEAU and Antoine PECQUET. Access to the source code contained herein is hereby forbidden to anyone except current people allowed explicitely by
/// Cédric EMONNEAU and Antoine PECQUET.
/// Confidentiality and Non-disclosure agreements explicitly covering such access.
///
/// The copyright notice above does not evidence any actual or intended publication or disclosure  of  this source code, which includes  
/// information that is confidential and/or proprietary, and is a trade secret, of Cédric EMONNEAU and Antoine PECQUET.   ANY REPRODUCTION, MODIFICATION,
/// DISTRIBUTION, PUBLIC  PERFORMANCE, 
/// OR PUBLIC DISPLAY OF OR THROUGH USE  OF THIS  SOURCE CODE  WITHOUT  THE EXPRESS WRITTEN CONSENT OF COMPANY IS STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
/// LAWS AND INTERNATIONAL TREATIES.  THE RECEIPT OR POSSESSION OF  THIS SOURCE CODE AND/OR RELATED INFORMATION DOES NOT CONVEY OR IMPLY ANY RIGHTS  
/// TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT  MAY DESCRIBE, IN WHOLE OR IN PART.                
///

#ifndef __SHELL_FCT_HEADER__
#define __SHELL_FCT_HEADER__

#include "cmd.h"
//Your imports come here

//Terminate shell
#define MYSHELL_FCT_EXIT 1

//Execute a command
int execCommand(cmd *c); 


#endif


