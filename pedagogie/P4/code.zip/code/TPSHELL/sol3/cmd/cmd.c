///
/// CONFIDENTIAL
/// Unpublished Copyright (c) 2016 Cédric EMONNEAU & Antoine PECQUET, All Rights Reserved.
///
/// NOTICE:  All information contained herein is, and remains the property of Cédric EMONNEAU and Antoine PECQUET. The intellectual and technical concepts contained
/// herein are proprietary to those autors and may be covered by French author copyright and Foreign Patents, and are protected by trade secret or copyright law.
/// Dissemination of this information or reproduction of this material is strictly forbidden unless prior written permission is obtained
/// from  Cédric EMONNEAU and Antoine PECQUET. Access to the source code contained herein is hereby forbidden to anyone except current people allowed explicitely by
/// Cédric EMONNEAU and Antoine PECQUET.
/// Confidentiality and Non-disclosure agreements explicitly covering such access.
///
/// The copyright notice above does not evidence any actual or intended publication or disclosure  of  this source code, which includes  
/// information that is confidential and/or proprietary, and is a trade secret, of Cédric EMONNEAU and Antoine PECQUET.   ANY REPRODUCTION, MODIFICATION,
/// DISTRIBUTION, PUBLIC  PERFORMANCE, 
/// OR PUBLIC DISPLAY OF OR THROUGH USE  OF THIS  SOURCE CODE  WITHOUT  THE EXPRESS WRITTEN CONSENT OF COMPANY IS STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
/// LAWS AND INTERNATIONAL TREATIES.  THE RECEIPT OR POSSESSION OF  THIS SOURCE CODE AND/OR RELATED INFORMATION DOES NOT CONVEY OR IMPLY ANY RIGHTS  
/// TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT  MAY DESCRIBE, IN WHOLE OR IN PART.                
///

#include "cmd.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "string.h"

//print some space on the screen to make the print look better
void printTabs(unsigned int n){
	unsigned int i = 0;
	for(i=0;i < n;++i)
		printf(" ");
}

//Print every bit of data of cmd
void printCmd(cmd *cmd){
	printf("Complete cmd:%s\n",cmd->initCmd);
	printf("Members(%d)\n",cmd->nbCmdMembers);
	int i;
	//printf("%s",cmd->cmdMembers[0]);
	for(i = 0; i < cmd->nbCmdMembers;++i){
	  printTabs(2);
		printf("|%s|\n",cmd->cmdMembers[i]);
		fflush(stdout);
		
	  int a;
	  printTabs(4);printf("Args(%d)\n",cmd->nbMembersArgs[i]);
	  fflush(stdout);
		for(a = 0; a < cmd->nbMembersArgs[i];++a){
		  printTabs(4);
		  printf("|%s|",cmd->cmdMembersArgs[i][a]);
		  fflush(stdout);
		}
		printf("\n");
		int m;
		printTabs(4);printf("STDIO\n");
		for(m=0; m < 3;++m){
		  printTabs(4);
		  printf("|%s(%d)|",cmd->redirection[i][m],cmd->redirectionType[i][m]);
		}
		printf("\n");
		
	}
	
	for(i = 0; i < cmd->nbCmdMembers;++i){
	  printTabs(2);
	}
	
	printf("\n");
}


//Remplit les champs initial_cmd, membres_cmd et nb_membres
void parseMembers(char *inputString,cmd *cmd){
  int debugCmd = 0;
  
  //internal command to say we want to debug the command (show it on the screen)
  if(inputString && *inputString == '$'){
    debugCmd = 1;
    ++inputString;
  }
  
  //creating a copy of the original string and cutting it in parts (separated with | )
  cmd->initCmd = duplicateString(inputString);
  cmd->nbCmdMembers = countCaracterOutsideString(cmd->initCmd,'|')+1;
  //cmd->nbCmdMembers = 1;
  cmd->cmdMembers = malloc(sizeof(char*)*cmd->nbCmdMembers);
  int i = 0;
  int iReal = 0;
  int realMembersNumber=0;
  char *saveptr;
  for(i=0;i < cmd->nbCmdMembers;++i,++iReal){
    cmd->cmdMembers[iReal] = strtok_r( i == 0 ? cmd->initCmd : NULL, "|", &saveptr);
    //printf("Explode %d:%s\n",i,cmd->cmdMembers[i]);
    if(cmd->cmdMembers[iReal] == NULL)
      --iReal;
    else
      ++realMembersNumber;
  }
  
  //allocate all members and initialize them
  cmd->nbCmdMembers = realMembersNumber;
  cmd->nbMembersArgs = malloc(sizeof(unsigned int)*cmd->nbCmdMembers);
  cmd->cmdMembersArgs = malloc(sizeof(char**)*cmd->nbCmdMembers);
  cmd->redirection = malloc(sizeof(char**)*cmd->nbCmdMembers);
  cmd->redirectionType = malloc(sizeof(int*)*cmd->nbCmdMembers);
  
  for(i=0;i < cmd->nbCmdMembers;++i){
    cmd->nbMembersArgs[i]=0;
    cmd->cmdMembersArgs[i]=NULL;
    cmd->redirection[i] = malloc(sizeof(char*)*3);
    cmd->redirectionType[i] = malloc(sizeof(int)*3);
    int a;
    for(a=0; a < 3;++a){
      cmd->redirectionType[i][a] = 0;
      cmd->redirection[i][a] = NULL;
    }
  }
  
  
  //interpret each members in order to create the associated structure
  int iMem = 0;
  for(iMem=0;iMem < cmd->nbCmdMembers;++iMem){
    char * string= cmd->cmdMembers[iMem];
    int start = 0;
    int end = 0;
    int isInQuote=0;
    int nbSpaces = 0;
    int appendToFile=0;
    int fileIn = 0;
    int errToRedirect = 0;
    int memberLength = strlen(string);
    
    if(memberLength > 0)
    for(i = 0; i < memberLength+1;++i){
      if(isInQuote || string[i] == '"'){
        if(string[i] == '"')
          isInQuote=!isInQuote;
        if(!isInQuote){}
        continue;
      }
      
      if(string[i] == ' ' || string[i] == '<' || string[i] == '>' || string[i]=='\0'){
        end = i;
        
        start+=nbSpaces;
        if(end-start > 0 && !isStringFullOf(string+start,string+end,' ')){
          
          
          if((string[start]=='2' && start+1 < memberLength && string[start+1] == '>') || (string[start]=='<' || string[start] == '>')){//not a param
            
            if(string[start]=='2'){
              start++;
              errToRedirect=1;
            }
            
            if(string[start]=='>'){
              ++appendToFile;
              if(end-start > 1){
                int pipeToRedirect = errToRedirect ? 2 : 1;
                cmd->redirection[iMem][pipeToRedirect]=copyStringWithInterval(string+start,string+end);
                if(appendToFile == 1)
                  cmd->redirectionType[iMem][pipeToRedirect] = APPEND;
                else
                  cmd->redirectionType[iMem][pipeToRedirect] = OVERRIDE;
              }
            }else{
              if(end-start > 1){
                ++start;
                cmd->redirection[iMem][0]=copyStringWithInterval(string+start,string+end);
                if(fileIn == 1)
                  cmd->redirectionType[iMem][0] = APPEND;
                else
                  cmd->redirectionType[iMem][0] = OVERRIDE;
              }else
                fileIn=1;
            }
          }else{//param
            char * stringStart = string+start;
            char * stringEnd = string+end;
            
            if(appendToFile >= 1){
              int pipeToRedirect = errToRedirect ? 2 : 1;
              cmd->redirection[iMem][pipeToRedirect]=copyStringWithInterval(string+start,string+end);
              if(appendToFile == 1)
                cmd->redirectionType[iMem][pipeToRedirect] = APPEND;
              else
                cmd->redirectionType[iMem][pipeToRedirect] = OVERRIDE;
            }
            else if(fileIn == 0){
              if(stringStart != stringEnd){
              ++cmd->nbMembersArgs[iMem];
              cmd->cmdMembersArgs[iMem] = realloc(cmd->cmdMembersArgs[iMem],sizeof(char**)*cmd->nbMembersArgs[iMem]);
              cmd->cmdMembersArgs[iMem][cmd->nbMembersArgs[iMem]-1]=copyStringWithInterval(stringStart,stringEnd);
              }
            }
            else{
              cmd->redirection[iMem][0]=copyStringWithInterval(stringStart,stringEnd);
              if(fileIn == 1)
                cmd->redirectionType[iMem][0] = APPEND;
              else
                cmd->redirectionType[iMem][0] = OVERRIDE;
            }
            appendToFile=0;
            fileIn=0;
            errToRedirect=0;
          }
          
          
          
        }
        nbSpaces = 0;
        
        start = i;
        end = start;
      }
      
      if(string[i] == ' ')
        ++nbSpaces;
    }
    ++cmd->nbMembersArgs[iMem];
    cmd->cmdMembersArgs[iMem] = realloc(cmd->cmdMembersArgs[iMem],sizeof(char**)*cmd->nbMembersArgs[iMem]);
    cmd->cmdMembersArgs[iMem][cmd->nbMembersArgs[iMem]-1]=NULL;
  }
  
  if(debugCmd)
    printCmd(cmd);
}

void freeCmd(cmd  * cmd){
  free(cmd->initCmd);
  int i;
  for(i=0; i < cmd->nbCmdMembers;++i){
    int m=0;
    for(m=0; m < cmd->nbMembersArgs[i];++m){
      if(cmd->cmdMembersArgs[i][m] != NULL)
        free(cmd->cmdMembersArgs[i][m]);
    }
    for(m=0; m < 3;++m){
      if(cmd->redirection[i][m] != NULL)
        free(cmd->redirection[i][m]);
    }
    free(cmd->cmdMembersArgs[i]);
    free(cmd->redirection[i]);
    free(cmd->redirectionType[i]);
  }
  free(cmd->redirection);
  free(cmd->redirectionType);
  free(cmd->cmdMembers);
  free(cmd->cmdMembersArgs);
  
}
