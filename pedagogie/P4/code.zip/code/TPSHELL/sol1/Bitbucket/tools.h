#ifndef TOOLS_H_INCLUDED
#define TOOLS_H_INCLUDED

#include "shell_fct.h"

int split(char*** parsedCommand, const char* splitCaracter, const char* myString, const char* exclusionStr);

void fatalError(const char* str);
#endif
