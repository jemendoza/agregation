#ifndef CMD_H_INCLUDED
#define CMD_H_INCLUDED

#include <stdio.h>
#include <string.h>
#include <readline/readline.h>
#include <readline/history.h>
#include <stdlib.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

#define STDIN 0
#define STDOUT 1
#define STDERR 2

#define NO_REDIRECTION -1
#define REPLACE 0
#define APPEND 1
#define IN 2

typedef struct commande {
	char *cmd_initiale;				/* La chaine initiale tapee par l'utilisateur */
	char **cmd_membres;				/* a chaque case i chaine du membre i */
	unsigned int nb_cmd_membres;	/* Nombre de membres */
	char ***cmd_membres_args;		/* cmd_membres_args[i][j] contient le jieme mot du ieme membre */
	unsigned int *nb_membres_args;	/* Nombre d'arguments par membres */
	char ***redirection;			/* Pour stocker le chemin vers le fichier de redirection */
	int **type_redirection;			/* Pour stocker le type de redirection */
} cmd;

void init_cmd(cmd *c);

void parse_membres(char *chaine, cmd *ma_cmd);
void parse_membres_args(cmd *ma_cmd);
void parse_redirection(cmd *ma_cmd);

void add_redirection(cmd *ma_cmd, int cpt,const char* key, char* str, int std, int type);

void aff_membres(cmd ma_cmd);
void aff_membres_args(cmd ma_cmd);
void aff_redirection(cmd ma_cmd);

void free_membres(cmd *ma_cmd);
void free_membres_args(cmd *ma_cmd);
void free_redirection(cmd *ma_cmd);

void cmd_destroy(cmd *ma_cmd);


#endif // CMD_H_INCLUDED
