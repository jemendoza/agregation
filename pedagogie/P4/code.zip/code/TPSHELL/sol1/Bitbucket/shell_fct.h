#ifndef SHELL_FCT_H_INCLUDED
#define SHELL_FCT_H_INCLUDED

#include <unistd.h>
#include <sys/wait.h>
#include <sys/types.h>
#include "cmd.h"

#define MYSHELL_CMD_OK 1
#define MYSHELL_FCT_EXIT 0

#define TIME_OUT 5

int exec_commande(cmd* ma_cmd);
void closeTube(int** tube, int length);

#endif // SHELL_FCT_H_INCLUDED
