#include <stdio.h>
#include <string.h>
#include <sys/types.h>
#include <pwd.h>

#include "shell_fct.h"
#include "cmd.h"

int main(int argc, char** argv)
{
	int ret;
	pid_t pid;
	cmd mycmd;

	char str[1024];
	char hostname[256];
	char workingdirectory[256];
    char* readlineptr;

    struct passwd* infos;

    ret = MYSHELL_CMD_OK;
	pid = getpid();
	readlineptr = NULL;

	while(ret != MYSHELL_FCT_EXIT)
	{
		infos = getpwuid(getuid());
		gethostname(hostname, 256);
		getcwd(workingdirectory, 256);
		sprintf(str, "\n{myshell pid = %d}%s@%s:%s$ ", pid, infos->pw_name, hostname, workingdirectory);
		readlineptr = readline(str);

		if (!strcmp(readlineptr,"exit"))
		{
			ret = MYSHELL_FCT_EXIT;
		}
		else
        {
            //add history to the shell
            add_history(readlineptr);

            //init cmd struct
            init_cmd(&mycmd);

            //parse
            parse_membres(readlineptr, &mycmd);
            parse_membres_args(&mycmd);
            parse_redirection(&mycmd);

            //aff
            aff_membres(mycmd);
            aff_membres_args(mycmd);
            aff_redirection(mycmd);

            //exec
            exec_commande(&mycmd);

            //free & stock command
            cmd_destroy(&mycmd);

        }
        free(readlineptr);
	}
	return 0;
}
