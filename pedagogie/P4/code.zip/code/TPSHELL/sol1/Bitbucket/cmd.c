#include "cmd.h"
#include "tools.h"

/*------STRUCT-----*/
void init_cmd(cmd *ma_cmd)
{
    ma_cmd->cmd_initiale = NULL;
    ma_cmd->cmd_membres = NULL;
    ma_cmd->cmd_membres_args = NULL;
    ma_cmd->nb_membres_args = NULL;
    ma_cmd->nb_cmd_membres = 0;
    ma_cmd->redirection = NULL;
    ma_cmd->type_redirection = NULL;
}

/*------PARSE-----*/
void parse_membres_args(cmd *ma_cmd)
{
    int cpt;

    for (cpt = 0; cpt < ma_cmd->nb_cmd_membres; cpt++)
    {
        ma_cmd->cmd_membres_args = (char***) realloc(ma_cmd->cmd_membres_args, sizeof(char**)*(cpt+1));
        if (ma_cmd->cmd_membres_args == NULL) { fatalError("Allocation Failed cm_membres args");}

        ma_cmd->nb_membres_args = (unsigned int*) realloc(ma_cmd->nb_membres_args, sizeof(unsigned int)*(cpt+1));
        if (ma_cmd->nb_membres_args == NULL) { fatalError("Allocation Failed nb_membres args");}

        ma_cmd->cmd_membres_args[cpt] = NULL;
        ma_cmd->nb_membres_args[cpt] = split(&ma_cmd->cmd_membres_args[cpt], " ", ma_cmd->cmd_membres[cpt], "<>");//on recupere le nombre d'argument de la commande penser a exclure les redirections ? caractére d'exclusion ou tab de caractére d'exclusion ex ici <><<>>

        //need to add NULL at the end of tab do delimit the end of tab for execvp
        ma_cmd->cmd_membres_args[cpt] = (char**) realloc(ma_cmd->cmd_membres_args[cpt], sizeof(char**)*(ma_cmd->nb_membres_args[cpt]+1));
        if (ma_cmd->cmd_membres_args[cpt] == NULL) { fatalError("Allocation Failed cm_membres args[]");}


        ma_cmd->cmd_membres_args[cpt][ma_cmd->nb_membres_args[cpt]] = NULL;

        /**
        *cmd_membres_args           ==> Tableau contenant les arg de toutes les commandes
        *cmd_menbres_args[i]        ==> Tableau qui contient la liste des arguments de la i eme cmd
        *cmd_menbres_args[i][j]     ==> Contient le j eme argument de la i eme cmd
        */
    }
}

void parse_membres(char *chaine, cmd *ma_cmd)
{
    ma_cmd->cmd_initiale = chaine;
    ma_cmd->nb_cmd_membres = split(&ma_cmd->cmd_membres, "|", chaine, "");
}

void parse_redirection(cmd *ma_cmd)
{
    int cpt;
    char* copyOfmyCmd;

    for (cpt = 0; cpt < ma_cmd->nb_cmd_membres; cpt++)
    {
        //allocation and initialisation
        ma_cmd->redirection = (char***) realloc(ma_cmd->redirection, sizeof(char**)*(cpt+1));
        if (ma_cmd->redirection == NULL) { fatalError("Allocation Failed redirection");}

        ma_cmd->redirection[cpt] = (char**) malloc(sizeof(char*)*3);
        if (ma_cmd->redirection[cpt] == NULL) { fatalError("Allocation Failed redirection[]");}

        ma_cmd->type_redirection = (int**) realloc(ma_cmd->type_redirection, sizeof(int*)*(cpt+1));
        if (ma_cmd->type_redirection == NULL) { fatalError("Allocation Failed type_redirection");}

        ma_cmd->type_redirection[cpt] = (int*) malloc(sizeof(int)*3);
        if (ma_cmd->type_redirection[cpt] == NULL) { fatalError("Allocation Failed type_redirection[]");}

        ma_cmd->redirection[cpt][STDIN] = NULL;
        ma_cmd->redirection[cpt][STDOUT] = NULL;
        ma_cmd->redirection[cpt][STDERR] = NULL;

        ma_cmd->type_redirection[cpt][STDIN] = NO_REDIRECTION;
        ma_cmd->type_redirection[cpt][STDOUT] = NO_REDIRECTION;
        ma_cmd->type_redirection[cpt][STDERR] = NO_REDIRECTION;

        //copy of the cpt ieme command
        copyOfmyCmd = strdup(ma_cmd->cmd_membres[cpt]);

        //out
        if (strstr(copyOfmyCmd, "2>>") != NULL)
        {
            //redirection type 2>>
            add_redirection(ma_cmd, cpt, "2>>", copyOfmyCmd, STDERR, APPEND);

        }
        else if (strstr(copyOfmyCmd, "2>") != NULL)
        {
            //redirection type 2>
            add_redirection(ma_cmd, cpt, "2>", copyOfmyCmd, STDERR, REPLACE);
        }

        if (strstr(copyOfmyCmd, ">>") != NULL)
        {
            //redirection type >>
            add_redirection(ma_cmd, cpt, ">>", copyOfmyCmd, STDOUT, APPEND);
        }
        else if (strstr(copyOfmyCmd, ">") != NULL)
        {
            //redirection type >
            add_redirection(ma_cmd, cpt, ">", copyOfmyCmd, STDOUT, REPLACE);
        }

        //in
        if (strstr(copyOfmyCmd, "<") != NULL)
        {
            //redirection type <
            if (strstr(copyOfmyCmd, ">") != NULL)
            {
                strtok(copyOfmyCmd, ">");//on supprime la redirection de la sortie qui a deja ete traité plus haut
            }

            add_redirection(ma_cmd, cpt, "<", copyOfmyCmd, STDIN, IN);
        }

        free(copyOfmyCmd);
        /**
        *redirection[0][STDIN] ==> redirection de l'entree
        *redirection[0][STDOUT] ==> redirection de la sortie
        *redirection[0][STDERR] ==> redirection de la sortie d'erreur
        *
        *type_redirection[0][STD..] ==> APPEND|REPLACE|NO_REDIRECTION|IN
        */
    }
}

/**
*@param ma_cmd : ma commande complete (structure)
*@param cpt : indice de la commande actuellement traitee
*@param key : string representant le type de redirection > ; >> ; 2> ; <
*@param str : commande actuellement traitee
*@param std : type de sortie standard STDERR ; STDIN ; STDOUT
*@param type: variante de la sortie REPLACE; APPEND ; IN
*/
void add_redirection(cmd* ma_cmd, int cpt, const char* key, char* str, int std, int type)
{
    char* buffer;
    buffer = strtok(str, key);
    buffer = strtok(NULL, key);
    ma_cmd->redirection[cpt][std] = strdup(buffer);
    ma_cmd->type_redirection[cpt][std] = type;

}


/*------DEBUG-----*/
void aff_membres_args(cmd ma_cmd)
{
    int cpt, cpt2;
    for (cpt = 0; cpt < ma_cmd.nb_cmd_membres; cpt++)
    {
        printf("Commande %d :\n", cpt);
        for (cpt2 = 0; cpt2 < ma_cmd.nb_membres_args[cpt]; cpt2++)
        {
            if (cpt2 == 0)
            {
                printf("----%s----\n", ma_cmd.cmd_membres_args[cpt][cpt2]);
            }
            else
            {
                printf("Arg %d : %s\n", cpt2, ma_cmd.cmd_membres_args[cpt][cpt2]);
            }
        }
    }
}

void aff_membres(cmd ma_cmd)
{
    int cpt;
    for (cpt = 0;cpt < ma_cmd.nb_cmd_membres; cpt++)
    {
        printf("Membre %d : %s\n", cpt, ma_cmd.cmd_membres[cpt]);
    }
}

void aff_redirection(cmd ma_cmd)
{
    int cpt, cpt2;
    for (cpt = 0; cpt < ma_cmd.nb_cmd_membres; cpt++)
    {
        for (cpt2 = 0; cpt2 < 3; cpt2++)
        {
            if (ma_cmd.redirection[cpt][cpt2] != NULL)
            {
                printf("redirection %d de %d: %s de type %d\n", cpt, cpt2, ma_cmd.redirection[cpt][cpt2], ma_cmd.type_redirection[cpt][cpt2]);
            }
        }
    }
}


/*------FREE & DESTROY-----*/
void free_membres_args(cmd *ma_cmd)
{
    int cpt, cpt2;
    for (cpt = 0; cpt < ma_cmd->nb_cmd_membres; cpt++)
    {
        for (cpt2 = 0; cpt2 < ma_cmd->nb_membres_args[cpt]+1; cpt2++)//+1 because we need to free the END of tab NULL (who'is need for execvp)
        {
            free(ma_cmd->cmd_membres_args[cpt][cpt2]);
        }
        free(ma_cmd->cmd_membres_args[cpt]);
    }
    free(ma_cmd->nb_membres_args);
    free(ma_cmd->cmd_membres_args);
}

void free_membres(cmd *ma_cmd)
{
    int cpt;
    for (cpt = 0; cpt < ma_cmd->nb_cmd_membres; cpt++)
    {
        free(ma_cmd->cmd_membres[cpt]);
    }
    free(ma_cmd->cmd_membres);
}

void free_redirection(cmd *ma_cmd)
{
    int cpt, cpt2;
    for (cpt = 0; cpt < ma_cmd->nb_cmd_membres; cpt++)
    {
        for (cpt2 = 0; cpt2 < 3; cpt2++)
        {
            free(ma_cmd->redirection[cpt][cpt2]);
        }
        free(ma_cmd->redirection[cpt]);
        free(ma_cmd->type_redirection[cpt]);
    }
    free(ma_cmd->redirection);
    free(ma_cmd->type_redirection);
}

void cmd_destroy(cmd *ma_cmd)
{
    free_membres_args(ma_cmd);
    free_membres(ma_cmd);
    free_redirection(ma_cmd);
}
