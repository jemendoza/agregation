#include "shell_fct.h"
#include "tools.h"

int exec_commande(cmd* ma_cmd)
{
    int cpt;
    pid_t process;
    int** tube;

    char str[255];

	tube = (int**) malloc(sizeof(int*)*ma_cmd->nb_cmd_membres-1);

	if (tube == NULL) { fatalError("Allocation Failed tube");}

    for (cpt = 0 ; cpt < ma_cmd->nb_cmd_membres-1 ; cpt++)//open n-1 pipes contained in tube
    {
        tube[cpt] = (int*) malloc(sizeof(int)*2);
        if (tube[cpt] == NULL) { fatalError("Allocation Failed tube[]");}
        if (pipe(tube[cpt]) == -1) { fatalError("Pipe open Failed");}

    }

    for(cpt = 0 ; cpt < ma_cmd->nb_cmd_membres ; cpt++)
    {
        process = fork();
        if(process == -1) { fatalError("fork"); }

        if(process == 0)
        {
            //child process
            if (ma_cmd->nb_cmd_membres == 1) {}//only one process NO PIPE nothing to be done with pipe
            else if (cpt == 0)//first process
            {
                //IF NO redirection dup to pipe
                if (ma_cmd->redirection[cpt][STDOUT] == NULL)
                {
                    //out in pipe
                    if (dup2(tube[cpt][1], 1) == -1) { fatalError("dup2 error");}//write to pipe
                }
                closeTube(tube, ma_cmd->nb_cmd_membres-1);

            }
            else if (cpt == ma_cmd->nb_cmd_membres-1)//last one
            {
                //IF NO IN redirection dup from pipe
                if (ma_cmd->redirection[cpt][STDIN] == NULL)
                {
                    //In from PIPE
                    if (dup2(tube[cpt-1][0], 0) == -1) { fatalError("dup2 error");}//read from pipe
                }
                closeTube(tube, ma_cmd->nb_cmd_membres-1);

            }
            else//other process
            {
                //If NO redirection IN/OUT dup from/to PIPE
                if (ma_cmd->redirection[cpt][STDIN] == NULL)
                {
                    //In from PIPE
                    if (dup2(tube[cpt-1][0], 0) == -1) { fatalError("dup2 error");}//read from pipe
                }

                if (ma_cmd->redirection[cpt][STDOUT] == NULL)
                {
                    //out to PIPE
                    if (dup2(tube[cpt][1], 1) == -1) { fatalError("dup2 error");}//write to pipe
                }
                closeTube(tube, ma_cmd->nb_cmd_membres-1);

            }

            gestionRedirection(ma_cmd, cpt); //gestion des redirections sur des fichiers

            //WATCH DOG !!! TIME OUT
            signal(SIGALRM, SIGKILL);
            alarm(TIME_OUT);

            if (execvp(ma_cmd->cmd_membres_args[cpt][0],ma_cmd->cmd_membres_args[cpt]) < 1)
            {
                sprintf(str, "Exectution failed pid %d Commande : %s ARG1 : %s ", getpid(), ma_cmd->cmd_membres_args[cpt][0], ma_cmd->cmd_membres_args[cpt][1]);
                fatalError(str);
            }
            exit(EXIT_SUCCESS);
        }
        else {
            //parent process
            if (cpt == ma_cmd->nb_cmd_membres-1)
            {
                //wait last process end
            }
        }
    }
                closeTube(tube, ma_cmd->nb_cmd_membres-1);
                waitpid(process, NULL, 0);
    return 0;
}

void closeTube(int** tube, int length)
{
    int cpt;
    for (cpt = 0 ; cpt < length ; cpt++)
    {
        if (close(tube[cpt][0]) == -1) { fatalError("Close tube[0] failed");}
        if (close(tube[cpt][1]) == -1) { fatalError("Close tube[1] failed");}
        free(tube[cpt]);
    }
    free(tube);
}

void gestionRedirection(cmd *ma_cmd, int cpt)
{
    int file;

	if (ma_cmd->redirection[cpt][STDOUT] != NULL)
	{
		if (ma_cmd->type_redirection[cpt][STDOUT] == APPEND)
		{
			//for >>
			file = open(ma_cmd->redirection[cpt][STDOUT], O_WRONLY | O_APPEND | O_CREAT); //ouvre en ecriture, j'ecris a la fin et si existe pas je cree
			if (file == -1) {fatalError("file redirection open FAILED");}
		}
		else
		{
			//for >
			file = open(ma_cmd->redirection[cpt][STDOUT], O_WRONLY | O_CREAT | O_TRUNC); //ouvre en ecriture et vide le fichier,cree s'il n'existe pas
			if (file == -1) {fatalError("file redirection open FAILED");}
		}

		dup2(file, 1); //duplique la sortie standard sur "l'entree" du fichier
		close(file);
	}

	if (ma_cmd->redirection[cpt][STDERR] != NULL)
	{
		if (ma_cmd->type_redirection[cpt][STDERR] == APPEND)
		{
			//for 2>>
			file = open(ma_cmd->redirection[cpt][STDERR], O_WRONLY | O_APPEND | O_CREAT); //
			if (file == -1) {fatalError("file redirection open FAILED");}
		}
		else
		{
			//for 2>
			file = open(ma_cmd->redirection[cpt][STDERR], O_WRONLY | O_CREAT | O_TRUNC);
			if (file == -1) {fatalError("file redirection open FAILED");}
		}

		dup2(file, 2); //duplique la sortie d'erreur sur "l'entree" du fichier
		close(file);
	}

    if (ma_cmd->redirection[cpt][STDIN] != NULL)
	{
		//for <
		file = open(ma_cmd->redirection[cpt][STDIN], O_RDONLY);
		if (file == -1) {fatalError("file redirection open FAILED");}
		dup2(file,0); //prend la lecture du fichier en entree standard
		close(file);
	}

}
