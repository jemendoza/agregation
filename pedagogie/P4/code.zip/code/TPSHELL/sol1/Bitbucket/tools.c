#include "tools.h"

int split(char*** parsedCommand,const char* splitCaracter,const char* myString, const char* exclusionStr)
{
    char* splittedPart = ""; //GERMAIN APREND A LIRE LA DOC ^^
    char* copyOfmyString = NULL;
    int argc = 0;

    copyOfmyString = strdup(myString);
    splittedPart = strtok(copyOfmyString, splitCaracter);

    while(splittedPart != NULL && strpbrk(splittedPart, exclusionStr) == NULL)//!tabCharInStr(exclusionTab, splittedPart))//tant que le caractere d'exclusion n'est pas dans la chaine
    {
        *parsedCommand = (char**) realloc(*parsedCommand, sizeof(char*)*(argc+1));
        if (*parsedCommand == NULL)
        {
            fatalError("Allocation Failed parsedCommand");
        }
        (*parsedCommand)[argc] = strdup(splittedPart);

        if ((*parsedCommand)[argc] == NULL)
        {
            fatalError("Allocation Failed parsedCommand[]");
        }

        splittedPart = strtok (NULL, splitCaracter);

        argc++;
    }

    free(copyOfmyString);
    return argc;
}

void fatalError(const char* str)
{
    perror(str);
    exit(errno);
}
