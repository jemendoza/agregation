#include <sys/types.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <signal.h>

//Auxiliary variable
int i;

//Signal handler
void sigHandler(int sigNumber)
{
	printf("Signal N° : %d, i=%d\n", sigNumber,i);
}

//Main function
int main(void)
{
	//Auxiliary variables
    pid_t pid;
	//Create the child process
	pid = fork();
	if(pid == 0)
	{	
        //Child's code
		
        //Case 1: stop execution
        //We do not have anything to do. This is the default behavior.
        
        //Case 2: ignore the signal
        //signal(SIGUSR1,SIG_IGN);
		
		//Case 3: respond to the signal by executing a singnal handler
		//signal(SIGUSR1, sigHandler);
		
		//Child's computations
		for(i = 0; i < 6; i++)
		{
			printf("I'm working hard...\n");
			sleep(1);
		}
        exit(EXIT_SUCCESS);
	}
	
    /*Short pause so the child has the time to configure
      the signal handler */
	sleep(2);
	
	//Case 1: kill the child process
    //kill(pid, SIGKILL);
	
    
	//Case 2: send signal SIGUSR1 to the child
    kill(pid, SIGUSR1);
    
    //Wait for the completion of the child process
    int status;
    wait(&status);
    
	exit(EXIT_SUCCESS);
}

