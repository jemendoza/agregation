#include <unistd.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <stdlib.h>
#include <stdio.h>
#include <errno.h>
#include <string.h>

//Auxiliary variables

// stores the process id of the child process
int pid;
// stores the FDs of the pipe use to transfer messages from the parent to the child
int tubeP[2];
// stores the FDs of the pipe use to transfer messages from the child to the parent
int tubeC[2];


//Error handler routine: call this function every time an error is produced
void error_and_die(const char *msg){
    perror(msg);
    exit(errno);
}

//Parent process closing routine. This handler should be called when the parent process receives a SIGINT signal
void arretPere(int sigNum){
    
    printf("\nClosing parent process\n");
    fflush(stdout);
	
    //i) kill child process
	kill(pid, SIGUSR2);
	
    //ii) close all remining fds
	if(close(tubeP[0]) == -1)
        error_and_die("close");
    
	if(close(tubeC[1]) == -1)
        error_and_die("close");
    
    exit(EXIT_SUCCESS);
}

//Child process closing routine. This handler should be called when the child process receives a SIGUSR2 signal.
void arretFils(int sigNum){
    
	printf("Closing child process with id=%d\n", getpid());
    fflush(stdout);
    
    //i) close fds
	if(close(tubeP[1]) == -1)
        error_and_die("close");
    if(close(tubeC[0]) == -1)
        error_and_die("close");
    
    exit(EXIT_SUCCESS);
}

//Main function
int main(void)
{
	//Auxiliary variables
    float a, b, result; //variables for the computations
	int pidResult;      //auxiliary variable for storing the pid of the child process sent in the response
    char buffer[128];   //buffer to store text
	int lenBuf;         //lenght of the buffer
	
    //i) open pipes
	if(pipe(tubeP) == -1)
        error_and_die("pipe");
	if(pipe(tubeC) == -1)
        error_and_die("pipe");
    
	//ii) create child process
    if((pid = fork()) == -1)
        error_and_die("fork");
    
    if(pid == 0){
        
        //Child's code
        
		//Auxiliary variables
        float var1, var2;
		
        //i) set up singal handlers
		signal(SIGINT, SIG_IGN); //Ignore Ctr + C
		signal(SIGUSR2, arretFils); //Close on SIGUSR2
		
        //ii) close unused fds
		if(close(tubeP[0]) == -1)
            error_and_die("close");
		if(close(tubeC[1]) == -1)
            error_and_die("close");
		
        //iii) wait for data + perform calculations + send response
		while(1)
		{
 			//i) read data from the pipe
            if((lenBuf = read(tubeC[0], buffer, 127)) == -1)
                error_and_die("read");
            
            //ii) parce data into working variables (see function sscanf)
			buffer[lenBuf] = '\0';
			if(sscanf(buffer, "%f %f", &var1, &var2) == EOF)
                error_and_die("sscanf");
            
            //iii) compute the result
			result = var1 + var2;
            
            //iv) build a string with the response (see function snprintf)
			if(snprintf(buffer, 128, "%d %f", getpid(), result) < 1)
                error_and_die("snprintf");
            
            //v) write the response to the pipe
			if(write(tubeP[1], buffer, lenBuf) == -1)
                error_and_die("write");
		}
        
        exit(EXIT_SUCCESS);
	}
	
    //Parent's code
    
    //i) close unused fds
	if(close(tubeP[1]) == -1)
        error_and_die("close");
	if(close(tubeC[0]) == -1)
        error_and_die("close");
    
    //ii) set up signal handlers
	signal(SIGINT, arretPere); //Close at Ctr + c
	
    //iii) wait for input, send data to child process, wait for response, print response
	while(1)
	{
		//i) read imput from the user (see function scanf)
        if(scanf("%f %f", &a, &b) == EOF)
            error_and_die("scanf");
        
        //ii) build a string with the data to transfer
		if((lenBuf = snprintf(buffer, 128, "%f %f", a, b)) < 0)
            error_and_die("snprintf");
        
        //iii) write data
		if((lenBuf = write(tubeC[1], buffer, lenBuf)) == -1)
            error_and_die("write");
        
        //iv) read response from the pipe
		if((lenBuf = read(tubeP[0], buffer, 127)) == -1)
            error_and_die("read");
		
        //v) parce response (see function sscanf)
        buffer[lenBuf] = '\0';
		if(sscanf(buffer, "%d %f", &pidResult, &result) == EOF)
            error_and_die("sscanf");
	
        //vi) print result to screen
		printf("Result: %f\n", result);
	}
	
    exit(EXIT_SUCCESS);
}


