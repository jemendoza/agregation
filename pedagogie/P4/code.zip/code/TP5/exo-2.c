#include <sys/types.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <signal.h>

//gobal auxiliary variables
int tube[2];
//the pipe should be declare dhere so the signal handler has access to it

//signal handler
void sigHandler(int sigNumber){
    //local auxiliary variables
    char buf[23];
    //read the message from the pipe
    read(tube[0],buf,23);
    //print the message
    printf("Message: %s\n", buf);
}

//main function
int main(void){
    
    //local auxiliary variables
    pid_t pid;
    
    //open the communication pipe
    pipe(tube);
    
    //create child process
    pid=fork();
    
    if(pid==0){ //child's code
        
        //close unused fds
        close(tube[1]);
        
        //install the signal handling mechanism
        signal(SIGUSR1, sigHandler);
        
        //Perform computation
        int i;
        for(i=0; i<6;i++){
            printf("I'm working hard...\n");
            sleep(1);
        }
        
        exit(EXIT_SUCCESS);
    }
    
    //parent's code
    
    //close unused fds
    close(tube[0]);
    
    //make a short pause so the child has time to configure the signal handler
    sleep(2);
    
    //send the message to the childe
    write(tube[1],"Message from the parent",23);
    
    //Send the signal SIGUSR1 to the child
    kill(pid,SIGUSR1);
    
    //close unused fds
    close(tube[1]);
    
    //wait for the completion of the child process
    int status;
    wait(&status);
    
    exit(EXIT_SUCCESS);
    
}
