#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <errno.h>

//Create a struct to share the results
struct shared{
    int ab;
    int cd;
    int ef;
};

int main(){
    
    //Constants
    const key_t key = 1234;
    
    //Variables
    pid_t pid1, pid2, pid3;
    int a,b,c,d,e,f;
    void* shared_mem;
    
    //Get input from the user
    printf("input a:");
    scanf("%d",&a);
    printf("input b:");
    scanf("%d",&b);
    printf("input c:");
    scanf("%d",&c);
    printf("input d:");
    scanf("%d",&d);
    printf("input e:");
    scanf("%d",&e);
    printf("input f:");
    scanf("%d",&f);
    
    
    //Parent process creates the shared memory
    int shmid = shmget(key,sizeof(struct shared),0666|IPC_CREAT);
    if(shmid == -1) exit(EXIT_FAILURE);
    
    //Fork child
    pid1 = fork();
    if(pid1 == 0){
        //Inside process 1 (a+b)
        //attach to shared memory
        shared_mem = shmat(shmid,(void*)0,0);
        if(shared_mem == (void*) -1) exit (EXIT_FAILURE);
        //"load" the struct to a local variable
        struct shared* shared_data = (struct shared*) shared_mem;
        shared_data->ab = a +b;
        
        //detach
        if(shmdt(shared_mem) == -1) exit (EXIT_FAILURE);
        exit(EXIT_SUCCESS);
        
    }else { //Back to parent process
        pid2 = fork();
        if(pid2 == 0){
            //Inside process (c+d)
            //attach to shared memory
            shared_mem = shmat(shmid,(void*) 0,0);
            if(shared_mem == (void*) -1) exit (EXIT_FAILURE);
            struct shared* shared_data = (struct shared*) shared_mem;
            shared_data->cd = c+d;
            
            //detach
            if(shmdt(shared_mem) == -1) exit (EXIT_FAILURE);
            exit(EXIT_SUCCESS);
            
        }else{//Back to parent process
            pid3 = fork();
            if(pid3 == 0){
                //Inside process (e+f)
                //attach to shared memory
                shared_mem = shmat(shmid,(void*) 0,0);
                if(shared_mem == (void*) -1) exit (EXIT_FAILURE);
                struct shared* shared_data = (struct shared*) shared_mem;
                shared_data->ef = e+f;
                
                //detach
                if(shmdt(shared_mem) == -1) exit (EXIT_FAILURE);
                
                exit(EXIT_SUCCESS);
            }
        }
    }
    
    //Wait child process termination
    int status_ab,status_cd,status_ef;
    waitpid(pid1,&status_ab,0);
    waitpid(pid2,&status_cd,0);
    waitpid(pid3,&status_ef,0);
    
    //Check if all child exited  normally
    if(!WIFEXITED(status_ab) || !WIFEXITED(status_cd)||!WIFEXITED(status_ef)){
        exit(EXIT_FAILURE);
    }
    
    //Parent attaches to memory
    shared_mem = shmat(shmid,(void*) 0,0);
    if(shared_mem == (void*) -1) exit (EXIT_FAILURE);
    struct shared* shared_data = (struct shared*) shared_mem;
    
    //Calculate result
    int result = (shared_data->ab)*(shared_data->cd)/(shared_data->ef);
    printf("Result is %d\n", result);
    
    //Parent detaches from shared memory and deletes
    if(shmdt(shared_mem) == -1) exit (EXIT_FAILURE);
    if(shmctl(shmid,IPC_RMID,0) == -1) exit(EXIT_FAILURE);
    
    return EXIT_SUCCESS;
    
}