#include <sys/types.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>

int main(void)
{
    //Variables
    pid_t pid;
    int status;
    
    //Create chid process
    pid = fork();
    
    if(pid == 0)
    {
        printf("CHILD: execution starts\n");
        sleep(2);
        printf("CHILD: nap ends\n");
        exit(0);

    }else{
        //Code for the parent
        sleep(1);
        printf("PARENT: else starts\n");
    }
    
    printf("PARENT: waiting for child\n");
    
    pid=wait(&status);
    
    printf("PARENT: execution ends\n");
    
    return 0;
}
