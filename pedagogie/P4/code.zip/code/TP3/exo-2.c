#include <sys/types.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>

int main(void)
{
    //Variables
    pid_t pid;
    int status;
    
    //Create chid process
    pid = fork();
    
    if(pid == 0)
    {
        //Code for the child
        printf("Hello, I am the child process, my process id is %d"
               ", and my parent's id is %d\n", (int)getpid(), (int)getppid());
        exit(0);

    }else{
        //Code for the parent
        printf("Hello, I am the parent process, my process id is %d"
               ", my parent's id is %d, and I am the parent of process %d\n",
               (int)getpid(), (int)getppid(),pid);
    }
    
    pid=wait(&status);
    
    printf("Child with id %d completed and returned %d\n",pid,status);
    
    return 0;
}

//The parent process may then issue a wait system call, which suspends the execution of the parent process while the child executes. When the child process terminates, it returns an exit status to the operating system, which is then returned to the waiting parent process.
