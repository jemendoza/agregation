#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/file.h>
#include <sys/mman.h>
#include <sys/wait.h>
#include <fcntl.h>
//Create a struct to share the results
struct shared{
    int ab;
    int cd;
    int ef;
};

void error_and_die(const char *msg){
    perror(msg);
    shm_unlink("MYSHM");
    exit(EXIT_FAILURE);
}

int main(){
    
    //Variables
    pid_t pid1, pid2, pid3;
    int a,b,c,d,e,f;
    int r;
    
    //Get input from the user
    printf("input a:");
    scanf("%d",&a);
    printf("input b:");
    scanf("%d",&b);
    printf("input c:");
    scanf("%d",&c);
    printf("input d:");
    scanf("%d",&d);
    printf("input e:");
    scanf("%d",&e);
    printf("input f:");
    scanf("%d",&f);
    
    //Parent process creates the shared memory
    int fd = shm_open("MYSHM", O_RDWR | O_CREAT | O_EXCL, S_IRUSR | S_IWUSR);
    if(fd==-1)
        error_and_die("shm_open");
    
    //Parent defines the size of the shared memory
    r=ftruncate(fd, sizeof(struct shared));
    if(r!=0)
        error_and_die("ftruncate");
    
    //Parent process maps the shared memory
    struct shared* shared_data = mmap(NULL, sizeof(struct shared), PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0);
    if(shared_data == MAP_FAILED)
        error_and_die("mmap");
    
    //Clean the house
    close(fd);
    
    //Create child process and do computations
    pid1 = fork();
    if(pid1 == 0){
        shared_data->ab =a+b;
        printf("a+b=%d\n",shared_data->ab);
        exit(EXIT_SUCCESS);
    }else { //Back to parent process
        pid2 = fork();
        if(pid2 == 0){
            //Inside process (c+d)
            shared_data->cd = c+d;
            printf("c+d=%d\n",shared_data->cd);
            exit(EXIT_SUCCESS);
        }else{//Back to parent process
            pid3 = fork();
            if(pid3 == 0){
                //Inside process (e+f)
                shared_data->ef = e+f;
                printf("e+f=%d\n",shared_data->ef);
                exit(EXIT_SUCCESS);
            }
        }
    }
    
    //Wait child process termination
    int status_ab,status_cd,status_ef;
    waitpid(pid1,&status_ab,0);
    waitpid(pid2,&status_cd,0);
    waitpid(pid3,&status_ef,0);
    
    //Check if all child exited normally
    if(!WIFEXITED(status_ab) || !WIFEXITED(status_cd)||!WIFEXITED(status_ef)){
        shm_unlink("MYSHM");
        exit(EXIT_FAILURE);
    }
    
    //Calculate result
    int result = ((shared_data->ab)*(shared_data->cd))/(shared_data->ef);
    printf("Result is %d\n", result);
    
    //Clean the house
    //Parent de-attaches the memory
    r=munmap(shared_data,sizeof(struct shared));
    if(r != 0)
    {
        error_and_die("nunmap");
    }
    //Parent removes share memory
    r=shm_unlink("MYSHM");
    if(r != 0){
        perror("shm_unlink");
        exit(EXIT_FAILURE);
    }

    return EXIT_SUCCESS;
    
}
