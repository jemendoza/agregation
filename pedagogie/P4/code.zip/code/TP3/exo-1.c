#include <sys/types.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>

int main(void)
{
    //Variables
    pid_t pid;
    
    //Create chid process
    pid = fork();
    
    if(pid == 0)
    {
        //Code for the child
        printf("Hello, I am the child process, my process id is %d"
               ", and my parent's id is %d\n", (int)getpid(), (int)getppid());
    }else{
        //Code for the parent
        printf("Hello, I am the parent process, my process id is %d"
               ", my parent's id is %d, and I am the parent of process %d\n",
               (int)getpid(), (int)getppid(),pid);
    }
    
    return 0;
}

/*
Answer to the question: Sometimes the child process prints that its parent 
 id is 1. The reason is that the parent process has completed its execution 
 and the root process (init) takes control of orphan processes. Process init
 has PID=1.
*/