#include <sys/types.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <errno.h>
#include <sys/wait.h>

int main(void)
{
    //Variables
	pid_t pid;
	int status;
	
    //Create child process
	pid = fork();
	if(pid == 0)
	{
        //Inside the child process
		//Execute ls - we need
		if(execlp("ls", "ls", "-l", NULL) == -1) {
            perror("execlp");
            exit(errno);
        }
		
    }else{
	
	//Synchronize parent and child processes
	wait(&status);
	
	printf("PARENT - Execution ended. Child returned : %d\n",
           WEXITSTATUS(status));
    }
    
	exit(EXIT_SUCCESS);
}

