#include <sys/types.h>
#include <unistd.h>
#include <sys/wait.h>
#include <stdio.h>
#include <stdlib.h>
#include <signal.h>

//Variables
pid_t pid;

//Signal handler
void sigHandler(int sigNum)
{
    printf("Signal handled: %d\n", sigNum);
}

int main(void)
{
    pid = fork();
    if(pid == 0)
    {
        //Setting up signal handler
        //signal(SIGUSR1, sigHandler);
        signal(SIGUSR1, SIG_IGN);
        
        //Simulate execution for 10 seconds
        execlp("sleep", "sleep", "10", NULL);

    }else{
        
        //Give enough time to child process to set up handler
        sleep(2);
        
        //"SIGUSR1" stops the process
        kill(pid, SIGUSR1);
        
        int status;
        wait(&status);
        
        if(WIFEXITED(status))
            printf("Child process successfully completed\n");
        else
            printf("Child process unsuccessfully completed\n");
        
    }
    
    exit(EXIT_SUCCESS);
    
}
