#include <sys/types.h>
#include <unistd.h>
#include <sys/wait.h>
#include <stdio.h>
#include <stdlib.h>
#include <signal.h>

//Variables
pid_t pid;

int main(void)
{
    pid = fork();
    if(pid == 0)
    {
        //Set up ignoring signal SIGUSR1
        signal(SIGUSR1, SIG_IGN);
        
        //Simulate 10 seconds of execution
        execlp("sleep", "sleep", "10", NULL);
        
    }else{
        
        //Give time to child to set up handler
        sleep(2);
        
        //Send the signal
        kill(pid, SIGKILL);
        printf("Signal sent...\n");
        
        int status;
        wait(&status);
        
        if(WIFEXITED(status))
            printf("Child process successfully completed\n");
        else
            printf("Child process unsuccessfully completed\n");
        
    }
    exit(EXIT_SUCCESS);
}




