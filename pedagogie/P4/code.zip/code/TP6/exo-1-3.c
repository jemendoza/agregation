#include <sys/types.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <errno.h>
#include <sys/wait.h>

int main(void)
{
    //Variables
    pid_t pidC1,pidC2,pidC3;
    int tubeC1C2[2], tubeC2C3[2], tubeC3P[2];
    char buffer[20];
    
    //Open pipe child 1 -> child 2
    pipe(tubeC1C2);
    
    //Execute ls -l
    pidC1 = fork();
    if(pidC1 == 0)
    {
        //Redirect output
        close(tubeC1C2[0]);
        dup2(tubeC1C2[1], 1);
        close(tubeC1C2[1]);
        
        //Execute ls
        if(execlp("ls", "ls", "-l", NULL) == -1) {
            perror("execlp");
            exit(errno);
        }
    }else{
        //Back to parent's code
        
        //Open pipe child 2 -> child 3
        pipe(tubeC2C3);
        
        //Execute tail -3
        pidC2 = fork();
        if(pidC2 == 0)
        {
            //Redirect input
            close(tubeC1C2[1]);
            dup2(tubeC1C2[0], 0);
            close(tubeC1C2[0]);
            
            //Redirect output
            close(tubeC2C3[0]);
            dup2(tubeC2C3[1], 1);
            close(tubeC2C3[1]);
            
            // execute "tail -3"
            if(execlp("tail", "tail", "-3", NULL) == -1){
                perror("execlp");
                exit(errno);
            }
            
        }else{
            //Back to parent's code
            
            /*Pipe child 1 -> child 2 is not used
             by the parent process or by child 3
             we should then close it
             */
            close(tubeC1C2[0]);
            close(tubeC1C2[1]);
            
            //Open pipe child 3 -> parent
            pipe(tubeC3P);
            
            //Execute "wc -w"
            pidC3 = fork();
            if(pidC3 == 0)
            {
                //Redirect input (from tubeC2C3)
                close(tubeC2C3[1]);
                dup2(tubeC2C3[0], 0);
                close(tubeC2C3[0]);
                
                //Redirect output (to tubeC3P)
                close(tubeC3P[0]);
                dup2(tubeC3P[1], 1);
                close(tubeC3P[1]);
                
                // exécution de "wc -w", un argument par paramètre
                if(execlp("wc", "wc", "-w", NULL) == -1) {
                    perror("execlp");
                    exit(errno);
                }
            }else{
                //Back to parent's code
                /*Pipe child 2 -> child 3 is not used
                 by the parent process.
                 We should then close it
                 */
                close(tubeC2C3[0]);
                close(tubeC2C3[1]);
                
                //Redirect input (from pipeC3P)
                close(tubeC3P[1]);
                dup2(tubeC3P[0], 0);
                close(tubeC3P[0]);
                
                //Synchronize
                int statusC1, statusC2, statusC3;
                waitpid(pidC1,&statusC1,0);
                waitpid(pidC2,&statusC2,0);
                waitpid(pidC3,&statusC3,0);
                
                /* Output to screen what is written on
                   pipeC3P
                */
                while(fgets(buffer, 20, stdin) != NULL)
                    printf("%s", buffer);
            }
        }
    }
    exit(EXIT_SUCCESS);
}

