#include <sys/types.h>
#include <unistd.h>
#include <sys/wait.h>
#include <stdio.h>
#include <stdlib.h>
#include <signal.h>

//Variables
pid_t pid;

//Alarm handler
void alarmHandler(int sigNum)
{
	printf("Alarm handled: killing child process\n");
	kill(pid, SIGKILL);
}

//Main
int main(void)
{
    //Create child process
	pid = fork();
	if(pid == 0)
	{
		int i;
		
        //Starting a long lasting task
		for(i = 0; i < 10; i++)
		{
			printf("Child process at work.... (%ds)\n", i);
			sleep(1);
		}
		
		printf("Fin du travail !\n");
		
    }else{
        //Back to parent process
        
        //Setting up the signal handler
        signal(SIGALRM, alarmHandler);
        
        //Setting up the timer
        alarm(5);
        printf("Alarm set\n");
        
        // attente de la fin du processus fils
        int status;
        wait(&status);
        
        if(WIFEXITED(status))
            printf("Child process successfully completed\n");
        else
            printf("Child process unsuccessfully completed\n");

    }
	
	exit(EXIT_SUCCESS);
}
