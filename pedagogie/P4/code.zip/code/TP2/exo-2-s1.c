#include <stdio.h>


int main(int argc, char **argv)
{
    int i;
    
    
    // FOR EACH FILE IN THE PARAMETERS
    for(i = 1; i < argc; i++)
    {
        //print the name of the file and break the line
        printf("%s\n", argv[i]);
    }
    
    return 0;
}
