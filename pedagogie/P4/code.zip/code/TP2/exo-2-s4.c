#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <sys/stat.h>



int main(int argc, char **argv)
{
    int i;
    struct stat fileStat;
    struct passwd *pwd;
    struct group *grp;
    char date[20];
    
    // FOR EACH FILE IN THE PARAMETERS
    for(i = 1; i < argc; i++)
    {
        // GET INFO
        if(lstat(argv[i], &fileStat)){
            //return value = -1 if error
            perror("stat");
            exit(errno);
        }
        
        // I-NODE NUMBER
        printf("%d ", (int)fileStat.st_ino);
        
        // FILE TYPE
        switch(fileStat.st_mode & S_IFMT)
        {
            case S_IFSOCK : printf("s"); break;
            case S_IFLNK : printf("l"); break;
            case S_IFREG : printf("-"); break;
            case S_IFBLK : printf("b"); break;
            case S_IFDIR : printf("d"); break;
            case S_IFCHR : printf("c"); break;
            case S_IFIFO : printf("p"); break;
            default : printf("?");
        }
        
        // PERMISSIONS
        // permissions for the owner
        if((fileStat.st_mode & S_IRUSR) == S_IRUSR)
            printf("r");
        else
            printf("-");
        if((fileStat.st_mode & S_IWUSR) == S_IWUSR)
            printf("w");
        else
            printf("-");
        if((fileStat.st_mode & S_IXUSR) == S_IXUSR){
            if((fileStat.st_mode & S_ISUID) == S_ISUID)
                printf("s");
            else
                printf("x");
        }
        else{
            if((fileStat.st_mode & S_ISUID) == S_ISUID)
                printf("S");
            else
                printf("-");
        }
        // permissions for the group
        if((fileStat.st_mode & S_IRGRP) == S_IRGRP)
            printf("r");
        else
            printf("-");
        if((fileStat.st_mode & S_IWGRP) == S_IWGRP)
            printf("w");
        else
            printf("-");
        if((fileStat.st_mode & S_IXGRP) == S_IXGRP){
            if((fileStat.st_mode & S_ISGID) == S_ISGID)
                printf("s");
            else
                printf("x");
        }
        else{
            if((fileStat.st_mode & S_ISGID) == S_ISGID)
                printf("S");
            else
                printf("-");
        }
        
        // permissions for other users
        if((fileStat.st_mode & S_IROTH) == S_IROTH)
            printf("r");
        else
            printf("-");
        if((fileStat.st_mode & S_IWOTH) == S_IWOTH)
            printf("w");
        else
            printf("-");
        if((fileStat.st_mode & S_IXOTH) == S_IXOTH){
            if((fileStat.st_mode & S_ISVTX) == S_ISVTX)
                printf("t");
            else
                printf("x");
        }
        else{
            if((fileStat.st_mode & S_ISVTX) == S_ISVTX)
                printf("T");
            else
                printf("-");
        }
        
        // FILE NAME
        printf(" %s\n", argv[i]);
    }
    
    return 0;
}
