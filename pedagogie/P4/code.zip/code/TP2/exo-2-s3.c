#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <sys/stat.h>

int main(int argc, char **argv)
{
    int i;
    struct stat fileStat;
    
    
    // FOR EACH FILE IN THE PARAMETERS
    for(i = 1; i < argc; i++)
    {
        // GET INFO
        if(lstat(argv[i], &fileStat)){
            //return value = -1 if error
            perror("stat");
            exit(errno);
        }
        
        // I-NODE NUMBER
        printf("%d ", (int)fileStat.st_ino);
        
        // FILE TYPE
        switch(fileStat.st_mode & S_IFMT)
        {
            case S_IFSOCK : printf("s"); break;
            case S_IFLNK : printf("l"); break;
            case S_IFREG : printf("-"); break;
            case S_IFBLK : printf("b"); break;
            case S_IFDIR : printf("d"); break;
            case S_IFCHR : printf("c"); break;
            case S_IFIFO : printf("p"); break;
            default : printf("?");
        }
        
        // nom du fichier et saut de ligne
        printf("%s\n", argv[i]);
    }
    
    return 0;
}
