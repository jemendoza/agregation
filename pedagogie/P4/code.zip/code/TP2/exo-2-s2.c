#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <sys/stat.h>

int main(int argc, char **argv)
{
    int i;
    struct stat fileStat;
    
    // FOR EACH FILE IN THE PARAMETERS
    for(i = 1; i < argc; i++)
    {
        // GET INFO
        if(lstat(argv[i], &fileStat)){
            //return value = -1 if error
            perror("stat");
            exit(errno);
        }
        
        // I-NODE NUMBER
        printf("%d ", (int)fileStat.st_ino);
        
        
        // FILE NAME
        printf("%s\n", argv[i]);
    }
    
    return 0;
}
