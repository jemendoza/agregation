#include <stdio.h>

int main(int argc, char **argv) 
{
	int i;
	
	//argc[0] holds the name of the program
    
	//print to screen all the arguments
	for(i = 1; i < argc; i++)
		printf("%s\t", argv[i]);
	printf("\n");
	
	return 0;
}
