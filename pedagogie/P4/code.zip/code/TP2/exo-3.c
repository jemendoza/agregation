#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <pwd.h>
#include <grp.h>
#include <time.h>
#include <dirent.h>

int main(int argc, char **argv)
{
    struct dirent *file;
    struct stat fileStat;
    struct passwd *pwd;
    struct group *grp;
    char date[20];
    DIR *directory;
    char fileName[256];
    
    // le nom du répertoir à lire doit être passé en premier paramètre
    if(argc < 2) exit(-1);
    
    // ouverture du répertoire
    if((directory = opendir(argv[1])) == NULL) {
        perror("opendir");
        exit(errno);
    }
    
    // pour tous les fichiers du répertoire
    while((file = readdir(directory)) != NULL)
    {
        
        //Build the file name
        snprintf(fileName, sizeof fileName, "%s%s%s", argv[1], "/", file->d_name);
        
        // collecte des infos
        if(lstat(fileName, &fileStat)) {
            perror("stat"); exit(errno);
        }
        
        // numéro d'I-noeud
        printf("%d ", (int)fileStat.st_ino);
        
        // mise en forme des permissions
        switch(fileStat.st_mode & S_IFMT)
        {
            case S_IFSOCK : printf("s"); break;
            case S_IFLNK : printf("l"); break;
            case S_IFREG : printf("-"); break;
            case S_IFBLK : printf("b"); break;
            case S_IFDIR : printf("d"); break;
            case S_IFCHR : printf("c"); break;
            case S_IFIFO : printf("p"); break;
            default : printf("?");
        }
        
        // PERMISSIONS
        // permissions for the owner
        if((fileStat.st_mode & S_IRUSR) == S_IRUSR)
            printf("r");
        else
            printf("-");
        if((fileStat.st_mode & S_IWUSR) == S_IWUSR)
            printf("w");
        else
            printf("-");
        if((fileStat.st_mode & S_IXUSR) == S_IXUSR){
            if((fileStat.st_mode & S_ISUID) == S_ISUID)
                printf("s");
            else
                printf("x");
        }
        else{
            if((fileStat.st_mode & S_ISUID) == S_ISUID)
                printf("S");
            else
                printf("-");
        }
        // permissions for the group
        if((fileStat.st_mode & S_IRGRP) == S_IRGRP)
            printf("r");
        else
            printf("-");
        if((fileStat.st_mode & S_IWGRP) == S_IWGRP)
            printf("w");
        else
            printf("-");
        if((fileStat.st_mode & S_IXGRP) == S_IXGRP){
            if((fileStat.st_mode & S_ISGID) == S_ISGID)
                printf("s");
            else
                printf("x");
        }
        else{
            if((fileStat.st_mode & S_ISGID) == S_ISGID)
                printf("S");
            else
                printf("-");
        }
        
        // permissions for other users
        if((fileStat.st_mode & S_IROTH) == S_IROTH)
            printf("r");
        else
            printf("-");
        if((fileStat.st_mode & S_IWOTH) == S_IWOTH)
            printf("w");
        else
            printf("-");
        if((fileStat.st_mode & S_IXOTH) == S_IXOTH){
            if((fileStat.st_mode & S_ISVTX) == S_ISVTX)
                printf("t");
            else
                printf("x");
        }
        else{
            if((fileStat.st_mode & S_ISVTX) == S_ISVTX)
                printf("T");
            else
                printf("-");
        }
        
        // nombre de liens dur
        printf(" %d ", (int)fileStat.st_nlink);
        
        // nom du propriétaire
        if ((pwd = getpwuid(fileStat.st_uid)) != NULL)
            printf("%s ", pwd->pw_name);
        else
            printf("%d ", fileStat.st_uid);
        
        // nom du groupe
        if ((grp = getgrgid(fileStat.st_gid)) != NULL)
            printf("%s ", grp->gr_name);
        else
            printf("%d ", fileStat.st_gid);
        
        // taille du fichier en octets
        printf("%d ", (int)fileStat.st_size);
        
        // DATE
        strftime(date, 20, "%b %d %H:%M", gmtime(&fileStat.st_mtime));
        printf("%s ", date);
        
        // nom du fichier et saut de ligne
        printf("%s\n", file->d_name);
    }
    
    // si une erreur s'est produite sur "readdir"
    if(errno != 0) {
        perror("stat"); exit(errno);
    }
    
    return 0;
}
